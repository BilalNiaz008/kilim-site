using System;
using System.Runtime.InteropServices;
using System.Threading;

namespace Kilim;

internal sealed class SoundSynth
{
    public float Slide, Volume = .5f;
    public int Trigger;
    float s1, s2, smooth, phase, envelope, amplitude, click;
    uint seed = 0x12345678;
    float Noise() { seed = unchecked(seed * 1664525 + 1013904223); return unchecked((int)seed) / 2147483648f; }
    public void Render(short[] output)
    {
        for (int i = 0; i < output.Length; i++)
        {
            smooth += (Volatile.Read(ref Slide) - smooth) * .0006f;
            float n = Noise(); s1 += (n - s1) * (.05f + .32f * smooth); s2 += (n - s2) * .006f;
            float rustle = (s1 - s2) * 1.05f * MathF.Pow(Math.Clamp(smooth, 0, 1), 1.15f);
            int trigger = Interlocked.Exchange(ref Trigger, 0);
            if (trigger > 0) { amplitude = trigger / 1000f; envelope = 1; phase = 0; }
            float thump = 0;
            if (envelope > .0004f)
            {
                phase += 2 * MathF.PI * (38 + 52 * envelope * envelope) / 44100;
                if (phase > 2 * MathF.PI) phase -= 2 * MathF.PI;
                click += (Noise() - click) * .07f;
                thump = (MathF.Sin(phase) * envelope * .9f + click * MathF.Pow(envelope, 6) * .8f) * amplitude;
                envelope *= .99984f;
            }
            float value = MathF.Tanh((rustle + thump) * Volatile.Read(ref Volume));
            output[i] = (short)(Math.Clamp(value, -1, 1) * short.MaxValue);
        }
    }
}

internal sealed class Audio : IDisposable
{
    [StructLayout(LayoutKind.Sequential, Pack = 2)] struct Format { public ushort Tag, Channels; public uint Rate, BytesPerSecond; public ushort Align, Bits, Extra; }
    [StructLayout(LayoutKind.Sequential)] struct Header { public nint Data; public uint Length, Recorded; public nuint User; public uint Flags, Loops; public nint Next; public nuint Reserved; }
    [DllImport("winmm.dll")] static extern uint waveOutOpen(out nint handle, uint device, ref Format format, nint callback, nint instance, uint flags);
    [DllImport("winmm.dll")] static extern uint waveOutPrepareHeader(nint handle, nint header, uint size);
    [DllImport("winmm.dll")] static extern uint waveOutUnprepareHeader(nint handle, nint header, uint size);
    [DllImport("winmm.dll")] static extern uint waveOutWrite(nint handle, nint header, uint size);
    [DllImport("winmm.dll")] static extern uint waveOutReset(nint handle);
    [DllImport("winmm.dll")] static extern uint waveOutClose(nint handle);
    public readonly SoundSynth Synth = new();
    readonly Thread worker;
    int stopped;
    long active;
    int impactWindow;
    float totalImpact;
    double lastThump = -10;
    readonly System.Collections.Generic.Queue<double> recent = new();
    public string? Error { get; private set; }
    public Audio() { worker = new Thread(Loop) { IsBackground = true, Name = "Kilim audio" }; worker.Start(); }
    public void Feed(Cloth cloth, bool enabled, float volume, bool carrying, double now)
    {
        Volatile.Write(ref Synth.Volume, enabled ? volume : 0);
        Volatile.Write(ref Synth.Slide, enabled ? Math.Clamp(cloth.Slide / 3, 0, 1) : 0);
        if (enabled && (cloth.Slide > .01f || cloth.Impact > 150)) Volatile.Write(ref active, Environment.TickCount64);
        if (!enabled) { impactWindow = 0; totalImpact = 0; return; }
        if (cloth.Impact > 150 && impactWindow == 0 && !carrying && cloth.Settled <= 20) { impactWindow = 6; totalImpact = 0; }
        if (impactWindow == 0) return;
        totalImpact += cloth.Impact; if (--impactWindow != 0) return;
        while (recent.Count > 0 && now - recent.Peek() > 4) recent.Dequeue();
        if (now - lastThump > .6 && totalImpact > 250 && recent.Count < 3)
        { Interlocked.Exchange(ref Synth.Trigger, (int)(MathF.Pow(MathF.Min(totalImpact / 3000, 1), .6f) * 900)); lastThump = now; recent.Enqueue(now); Volatile.Write(ref active, Environment.TickCount64); }
        totalImpact = 0;
    }
    public void Quiet() { Volatile.Write(ref Synth.Slide, 0); }
    void Loop()
    {
        nint device = 0; var headers = new nint[3]; var data = new nint[3]; uint size = (uint)Marshal.SizeOf<Header>();
        try
        {
            var format = new Format { Tag = 1, Channels = 1, Rate = 44100, BytesPerSecond = 88200, Align = 2, Bits = 16 };
            uint result = waveOutOpen(out device, uint.MaxValue, ref format, 0, 0, 0);
            if (result != 0) { Error = "Audio device unavailable (" + result + ")."; return; }
            for (int i = 0; i < 3; i++)
            {
                data[i] = Marshal.AllocHGlobal(882 * 2); headers[i] = Marshal.AllocHGlobal((int)size);
                Marshal.StructureToPtr(new Header { Data = data[i], Length = 882 * 2 }, headers[i], false);
                if (waveOutPrepareHeader(device, headers[i], size) != 0) throw new InvalidOperationException("Audio buffer could not be prepared.");
            }
            var samples = new short[882]; var submitted = new bool[3];
            while (Volatile.Read(ref stopped) == 0)
            {
                bool idle = Environment.TickCount64 - Volatile.Read(ref active) > 1400;
                for (int i = 0; i < 3; i++)
                {
                    var header = Marshal.PtrToStructure<Header>(headers[i]);
                    if (submitted[i] && (header.Flags & 1) == 0) continue;
                    if (idle) continue;
                    Synth.Render(samples); Marshal.Copy(samples, 0, data[i], samples.Length);
                    if (waveOutWrite(device, headers[i], size) != 0) throw new InvalidOperationException("Audio playback failed.");
                    submitted[i] = true;
                }
                Thread.Sleep(idle ? 100 : 8);
            }
        }
        catch (Exception e) { Error = e.Message; }
        finally
        {
            if (device != 0) waveOutReset(device);
            for (int i = 0; i < 3; i++)
            {
                if (headers[i] != 0) { if (device != 0) waveOutUnprepareHeader(device, headers[i], size); Marshal.FreeHGlobal(headers[i]); }
                if (data[i] != 0) Marshal.FreeHGlobal(data[i]);
            }
            if (device != 0) waveOutClose(device);
        }
    }
    public void Dispose() { Volatile.Write(ref stopped, 1); worker.Join(); }
}
