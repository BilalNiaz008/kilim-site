using System;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Automation;
using System.Windows.Media.Imaging;
using System.IO;

namespace Kilim;

internal sealed class LicenseWindow : Window
{
    readonly Licensing licensing;
    readonly PasswordBox input = new() { MaxLength = 500, Padding = new Thickness(10), FontSize = 15, MinHeight = 42 };
    readonly TextBlock status = new() { TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 16, 0, 14), FontSize = 14 };
    readonly Button activate = new() { Content = "Activate this PC", IsDefault = true, MinHeight = 42, Padding = new Thickness(16, 5, 16, 5) };
    readonly Button forget = new() { Content = "Forget saved key", MinHeight = 36, Padding = new Thickness(12, 4, 12, 4) };
    readonly CancellationTokenSource lifetime = new();
    bool busy;

    public LicenseWindow(Licensing licensing)
    {
        this.licensing = licensing;
        Title = "Activate Kilim for Windows"; Width = 480; SizeToContent = SizeToContent.Height;
        WindowStartupLocation = WindowStartupLocation.CenterScreen; ResizeMode = ResizeMode.NoResize;
        Background = new SolidColorBrush(Color.FromRgb(234, 243, 248));
        Foreground = new SolidColorBrush(Color.FromRgb(20, 46, 64));
        var panel = new StackPanel { Margin = new Thickness(28) };
        TextBlock Text(string value, int size = 14, FontWeight? weight = null) => new()
        { Text = value, FontSize = size, FontWeight = weight ?? FontWeights.Normal, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 0, 14) };
        panel.Children.Add(Text("Your rug needs its licence key.", 24, FontWeights.SemiBold));
        panel.Children.Add(Text("Copy your key from your Polar purchases. It activates this PC and Windows user. Internet access is required to start the app and for checks every 30 minutes."));
        var label = new Label { Content = "_Licence key", Target = input, Padding = new Thickness(0), Margin = new Thickness(0, 4, 0, 6) };
        panel.Children.Add(label); AutomationProperties.SetName(input, "Polar licence key"); panel.Children.Add(input);
        AutomationProperties.SetLiveSetting(status, AutomationLiveSetting.Polite);
        panel.Children.Add(status);
        activate.Foreground = Brushes.White; activate.Background = new SolidColorBrush(Color.FromRgb(125, 40, 61));
        var row = new WrapPanel(); row.Children.Add(activate);
        var exit = new Button { Content = "Exit", IsCancel = true, MinHeight = 42, Padding = new Thickness(16, 5, 16, 5), Margin = new Thickness(10, 0, 0, 0) };
        row.Children.Add(exit); panel.Children.Add(row);
        panel.Children.Add(Text("The saved key is protected by Windows. Copying the app folder does not copy this PC's activation.", 12));
        var controls = new WrapPanel { Margin = new Thickness(0, 8, 0, 0) };
        var purchases = new Button { Content = "Open Polar purchases", MinHeight = 36, Padding = new Thickness(12, 4, 12, 4), Margin = new Thickness(0, 0, 8, 8) };
        purchases.IsEnabled = PortalUrl() != null;
        purchases.Click += (_, _) => OpenPortal(); controls.Children.Add(purchases);
        forget.Margin = new Thickness(0, 0, 0, 8); controls.Children.Add(forget); panel.Children.Add(controls);
        panel.Children.Add(Text("To move your licence, deactivate the old PC in Polar first. Forgetting a saved key here does not release its Polar activation slot.", 12));
        Content = panel;
        activate.Click += async (_, _) => await Check(async () =>
        {
            if (input.Password.Trim().Length == 0)
            {
                if (!await licensing.Restore(lifetime.Token)) throw new LicenseError("Paste your licence key to activate this PC.");
            }
            else await licensing.Activate(input.Password, lifetime.Token);
        });
        forget.Click += (_, _) =>
        {
            if (MessageBox.Show(this, "This only removes the local saved key. Deactivate the old PC in Polar first, or its slot will remain allocated. Forget it here?",
                "Forget saved key", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
            try { licensing.Forget(); status.Text = "Saved key removed. Paste a key after releasing the old activation in Polar."; }
            catch (Exception e) when (e is System.IO.IOException or UnauthorizedAccessException) { status.Text = "Windows could not remove the saved key. Check folder permissions."; }
        };
        if (!licensing.Client.Configured)
        {
            input.IsEnabled = activate.IsEnabled = forget.IsEnabled = false;
            status.Text = "This build is awaiting Polar licence configuration. Ask the publisher for the configured version.";
        }
        else status.Text = "Checking for a saved activation...";
        Loaded += async (_, _) =>
        {
            if (!licensing.Client.Configured) return;
            await Check(async () =>
            {
                if (!await licensing.Restore(lifetime.Token)) throw new LicenseError("Paste your licence key from Polar to get started.");
            });
        };
        Closed += (_, _) => lifetime.Cancel();
    }
    async Task Check(Func<Task> operation)
    {
        if (busy) return; busy = true;
        activate.IsEnabled = input.IsEnabled = forget.IsEnabled = false; status.Text = "Checking your licence with Polar...";
        try
        {
            await operation();
            if (!lifetime.IsCancellationRequested) { input.Clear(); DialogResult = true; }
        }
        catch (OperationCanceledException) when (lifetime.IsCancellationRequested) { }
        catch (LicenseError error) { if (!lifetime.IsCancellationRequested) status.Text = error.Message; }
        catch (Exception error) when (error is System.IO.IOException or UnauthorizedAccessException or System.Security.Cryptography.CryptographicException)
        { if (!lifetime.IsCancellationRequested) status.Text = "Windows could not read or save the licence. Check folder permissions and retry."; }
        finally
        {
            busy = false;
            if (!lifetime.IsCancellationRequested) { activate.IsEnabled = input.IsEnabled = forget.IsEnabled = true; input.Focus(); }
        }
    }
    static Uri? PortalUrl()
    {
        string expected = LicenseConfig.Sandbox ? "sandbox.polar.sh" : "polar.sh";
        return Uri.TryCreate(LicenseConfig.CustomerPortalUrl, UriKind.Absolute, out var url) && url.Scheme == "https" &&
            url.Host == expected && url.IsDefaultPort && string.IsNullOrEmpty(url.UserInfo) &&
            System.Text.RegularExpressions.Regex.IsMatch(url.AbsolutePath, "^/[a-zA-Z0-9_-]+/portal/?$") ? url : null;
    }
    internal static void OpenPortal()
    {
        if (PortalUrl() is not Uri url) return;
        try { Process.Start(new ProcessStartInfo(url.AbsoluteUri) { UseShellExecute = true }); }
        catch (Exception error) when (error is System.ComponentModel.Win32Exception or InvalidOperationException)
        { MessageBox.Show("Your browser could not be opened. Use the purchases link in your Polar order email.", "Kilim purchases"); }
    }
    internal static void SavePreview(string file)
    {
        using var licensing = new Licensing();
        var window = new LicenseWindow(licensing);
        var body = (UIElement)window.Content; window.Content = null;
        var border = new Border { Background = window.Background, Child = body, Width = 480 };
        border.Measure(new Size(480, double.PositiveInfinity)); int height = (int)Math.Ceiling(border.DesiredSize.Height);
        border.Arrange(new Rect(0, 0, 480, height)); border.UpdateLayout();
        var image = new RenderTargetBitmap(480, height, 96, 96, PixelFormats.Pbgra32); image.Render(border);
        var encoder = new PngBitmapEncoder(); encoder.Frames.Add(BitmapFrame.Create(image));
        Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(file))!);
        using var stream = File.Create(file); encoder.Save(stream);
    }
}
