using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace Kilim;

// One runnable check suite. All provider traffic is mocked; it never sends a real key or activates Polar.
internal static class LicenseChecks
{
    const string Organization = "af61a3ec-6a0b-4fd8-b0b4-01f72b76b236", Benefit = "ef6c1673-3456-4709-bf52-a21652189420";
    const string Key = "KILIM_TEST_ONLY", Activation = "ce3f2d33-69ae-48f2-b09f-3394393a787a", LicenseId = "b00d049c-b7a5-4fbb-a08a-2a54e8f66dbe";
    const string Device = "test-device-hash";
    static void Assert(bool ok, string message) { if (!ok) throw new InvalidOperationException("Licence self-test failed: " + message); }
    static Dictionary<string, object?> License() => new()
    {
        ["id"] = LicenseId, ["organization_id"] = Organization, ["benefit_id"] = Benefit,
        ["key"] = Key, ["status"] = "granted", ["limit_activations"] = 1, ["expires_at"] = null,
        ["activation"] = new { id = Activation, license_key_id = LicenseId }
    };
    static HttpResponseMessage Json(object data) => new(HttpStatusCode.OK)
    { Content = new StringContent(JsonSerializer.Serialize(data), Encoding.UTF8, "application/json") };
    sealed class Fake : HttpMessageHandler
    {
        public Func<string, HttpResponseMessage> Reply = action => action == "activate"
            ? Json(new { id = Activation, license_key_id = LicenseId, license_key = License() })
            : action == "deactivate" ? new(HttpStatusCode.NoContent) : Json(License());
        public readonly List<(string action, JsonElement body)> Requests = new();
        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken token)
        {
            Assert(request.RequestUri!.Host is "api.polar.sh" or "sandbox-api.polar.sh", "official API host");
            Assert(request.Headers.Authorization == null, "no embedded access token");
            using var doc = JsonDocument.Parse(await request.Content!.ReadAsStringAsync(token));
            string action = request.RequestUri.Segments.Last(); Requests.Add((action, doc.RootElement.Clone()));
            return Reply(action);
        }
    }
    static async Task Rejected(Func<Task> action, string message, bool retryable = false)
    {
        try { await action(); }
        catch (LicenseError error) { Assert(error.Retryable == retryable, message + " retry policy"); Assert(!error.Message.Contains(Key), "key omitted from error"); return; }
        throw new InvalidOperationException("Licence self-test failed: accepted " + message);
    }
    public static async Task<int> Run(string[] args)
    {
        string output = args.Length > 1 ? Path.GetFullPath(args[1]) : Path.Combine(AppContext.BaseDirectory, "license-checks");
        Directory.CreateDirectory(output);
        var fake = new Fake(); using var client = new LicenseClient(Organization, Benefit, false, fake);
        var state = await client.Activate(Key, Device);
        Assert(state.ActivationId == Activation && state.Device == Device, "activation saved with the device");
        Assert(fake.Requests.Count == 2 && fake.Requests[0].action == "activate" && fake.Requests[1].action == "validate", "activation always followed by validation");
        var validated = fake.Requests[1].body;
        Assert(validated.GetProperty("benefit_id").GetString() == Benefit && validated.GetProperty("activation_id").GetString() == Activation &&
            validated.GetProperty("conditions").GetProperty("device").GetString() == Device, "product and device scoped request");
        Assert(!validated.TryGetProperty("increment_usage", out _), "checks do not consume quota");
        await client.Deactivate(state); Assert(fake.Requests.Last().action == "deactivate", "deactivation endpoint");
        fake.Reply = _ => Json(new { });
        await Rejected(() => client.Deactivate(state), "unconfirmed deactivation");

        foreach (string field in new[] { "organization_id", "benefit_id", "status", "key", "expires_at", "limit_activations", "activation" })
        {
            var altered = License();
            altered[field] = field switch
            {
                "status" => "revoked", "key" => "ANOTHER_KEY", "expires_at" => "2000-01-01T00:00:00Z",
                "limit_activations" => null, "activation" => new { id = Guid.NewGuid(), license_key_id = LicenseId }, _ => Guid.NewGuid().ToString()
            };
            fake.Reply = _ => Json(altered); await Rejected(() => client.Validate(state), "mismatched " + field);
        }
        var malformedExpiry = License(); malformedExpiry["expires_at"] = "not a date";
        fake.Reply = _ => Json(malformedExpiry); await Rejected(() => client.Validate(state), "malformed expiry");
        fake.Reply = _ => new(HttpStatusCode.OK) { Content = new StringContent("not json") };
        await Rejected(() => client.Validate(state), "malformed JSON", true);
        fake.Reply = _ => Json(new { }); await Rejected(() => client.Validate(state), "incomplete response");
        fake.Reply = _ => new(HttpStatusCode.NotFound) { Content = new StringContent(Key) };
        await Rejected(() => client.Validate(state), "revoked key HTTP response");
        fake.Reply = _ => new(HttpStatusCode.TooManyRequests); await Rejected(() => client.Validate(state), "rate limit", true);
        fake.Reply = _ => throw new HttpRequestException(); await Rejected(() => client.Validate(state), "offline connection", true);
        fake.Reply = _ => throw new TaskCanceledException(); await Rejected(() => client.Validate(state), "timeout", true);
        var missing = new Fake(); using var unconfigured = new LicenseClient("", "", false, missing);
        await Rejected(() => unconfigured.Activate(Key, Device), "empty provider configuration");
        Assert(missing.Requests.Count == 0, "empty configuration never calls provider");
        await Rejected(() => client.Validate(state with { Sandbox = true }), "wrong environment");

        fake.Requests.Clear();
        fake.Reply = action =>
        {
            if (action == "deactivate") return new(HttpStatusCode.NoContent);
            var wrong = License(); wrong["benefit_id"] = Guid.NewGuid().ToString();
            return Json(new { id = Activation, license_key_id = LicenseId, license_key = wrong });
        };
        await Rejected(() => client.Activate(Key, Device), "another product's activation");
        Assert(fake.Requests.Last().action == "deactivate", "release wrong-product allocation");
        fake.Reply = _ => new(HttpStatusCode.Forbidden);
        await Rejected(() => client.Activate(Key, Device), "device limit reached");

        string file = Path.Combine(output, "protected-test-activation.dat"); var store = new LicenseStore(file, Device);
        store.Save(state); Assert(store.Load() == state, "protected credential round trip");
        Assert(!Encoding.UTF8.GetString(File.ReadAllBytes(file)).Contains(Key), "saved key is not plaintext");
        var copied = new LicenseStore(file, "other-device");
        await Rejected(() => { copied.Load(); return Task.CompletedTask; }, "copied activation");
        byte[] damaged = File.ReadAllBytes(file); damaged[damaged.Length / 2] ^= 0x7f; File.WriteAllBytes(file, damaged);
        await Rejected(() => { store.Load(); return Task.CompletedTask; }, "modified credential file");
        store.Delete(); Assert(!File.Exists(file), "credential removal");

        await File.WriteAllTextAsync(Path.Combine(output, "license-report.json"), JsonSerializer.Serialize(new
        {
            passed = true, livePolarTested = false,
            checks = new[] { "activate then validate", "no secret token", "organization and product scope", "one-device limit", "expiry and revocation rejection", "activation identity", "timeouts and offline fail closed", "configuration required", "wrong environment", "wrong-product allocation cleanup", "deactivation confirmation required", "DPAPI credentials", "copied/tampered activation rejected" }
        }, new JsonSerializerOptions { WriteIndented = true }));
        Console.WriteLine("Licence checks passed (mocked Polar only)."); return 0;
    }
}
