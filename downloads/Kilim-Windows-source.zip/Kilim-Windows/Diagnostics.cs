using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Text.Json;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Kilim;

internal static class Diagnostics
{
    public static int Run(string[] args)
    {
        string output = args.Length > 1 ? Path.GetFullPath(args[1]) : Path.Combine(AppContext.BaseDirectory, "selftest");
        Directory.CreateDirectory(output);
        void Check(bool condition, string message) { if (!condition) throw new InvalidOperationException("Self-test failed: " + message); }
        var cloth = new Cloth { ViewWidth = 1100, ViewHeight = 760 };
        cloth.Bumps.Add(new Vector2(660, 380)); cloth.Bumps.Add(new Vector2(740, 450));
        Check(cloth.HeightAt(660, 380) == 20 && MathF.Abs(cloth.HeightAt(691, 380) - 10) < .001f, "icon height profile");
        cloth.Reset(new Vector2(590, 390), 620);
        Check(cloth.ConstraintCount == 7552, "constraint count");
        var watch = Stopwatch.StartNew();
        for (int i = 0; i < 360; i++) cloth.Step();
        double stepMs = watch.Elapsed.TotalMilliseconds / 360;
        Check(cloth.P.All(p => float.IsFinite(p.X) && float.IsFinite(p.Y) && float.IsFinite(p.Z)), "finite landed positions");
        Check(cloth.P.All(p => p.Z >= cloth.HeightAt(p.X, p.Y) - .01), "floor contact");
        Check(cloth.Hit(new Vector2(590, 390)) >= 0, "mesh hit test");
        var texture = Textures.Load("kashan");
        var scene = new Scene(1100, 760, Vector2.Zero, texture);
        scene.Update(cloth, "day", 1, new DateTime(2026, 10, 7, 12, 0, 0));
        Scene.SavePreview(scene, Path.Combine(output, "01-desktop-rug.png"), 1100, 760);
        var grab = cloth.Screen[15 * Cloth.NX + Cloth.NX - 4];
        Check(cloth.BeginGrab(grab), "grab edge");
        for (int i = 0; i < 80; i++) { cloth.MoveGrab(grab + new Vector2(-3.5f * i, .7f * i)); cloth.Step(); }
        scene.Update(cloth, "day", 1); Scene.SavePreview(scene, Path.Combine(output, "02-fold.png"), 1100, 760);
        cloth.EndGrab(); Check(!cloth.Grabbed, "release pins");
        for (int i = 0; i < 120; i++) cloth.Step();
        cloth.ToggleRoll(true); for (int i = 0; i < 130; i++) cloth.Step();
        Check(cloth.Rolling && cloth.RollProgress == 1 && cloth.P.Max(p => p.Z) > 20, "rolled pose");
        scene.Update(cloth, "evening", 1); Scene.SavePreview(scene, Path.Combine(output, "03-rolled.png"), 1100, 760);
        cloth.ToggleRoll(false); for (int i = 0; i < 120; i++) cloth.Step();
        Check(!cloth.Rolling && cloth.RollProgress == 0, "unroll returns to physics");
        float width = cloth.Width; cloth.Scale(1.25f); Check(MathF.Abs(cloth.Width - width * 1.25f) < .01, "resize");
        var before = cloth.Center(); var bump = cloth.Bumps[0]; cloth.Translate(new Vector2(-200, 100));
        Check(Vector2.Distance(cloth.Center(), before + new Vector2(-200, 100)) < .02f && cloth.Bumps[0] == bump + new Vector2(-200, 100), "monitor-origin translation");
        foreach (string theme in Textures.Themes)
        {
            var image = Textures.Load(theme); Check(image.PixelWidth > 100 && image.PixelHeight > 100, "texture " + theme);
            var png = new PngBitmapEncoder(); png.Frames.Add(BitmapFrame.Create(image));
            using var file = File.Create(Path.Combine(output, "theme-" + theme + ".png")); png.Save(file);
        }
        var custom = Textures.Custom(Path.Combine(AppContext.BaseDirectory, "assets", "kashan.jpg"));
        Check(custom.PixelWidth == 768 && custom.PixelHeight == 516, "custom weaving");
        var samples = new short[44100]; var synth = new SoundSynth(); synth.Render(samples);
        Check(samples.All(s => s == 0), "silence"); synth.Slide = 1; synth.Trigger = 900; synth.Render(samples);
        Check(samples.Any(s => Math.Abs((int)s) > 100), "generated rustle and thump");
        File.WriteAllText(Path.Combine(output, "report.json"), JsonSerializer.Serialize(new
        {
            passed = true, particles = Cloth.Count, triangles = 2 * (Cloth.NX - 1) * (Cloth.NY - 1), constraints = cloth.ConstraintCount,
            solver_step_ms = stepMs, patterns = Textures.Themes.Length,
            checks = new[] { "bump profile", "finite physics", "floor contact", "hit test", "grabbing", "roll/unroll", "resize", "display translation", "15 textures", "custom weaving", "audio" },
            caveat = "Synthetic model and offscreen WPF rendering; desktop interaction is checked separately."
        }, new JsonSerializerOptions { WriteIndented = true }));
        Console.WriteLine("All checks passed. Physics step: " + stepMs.ToString("F2") + " ms. Output: " + output);
        return 0;
    }
}
