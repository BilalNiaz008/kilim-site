# Polar activation — configured in 0.3.0-beta

The app asks for a Polar key before constructing the desktop rug. It checks saved credentials online at every launch and every 30 minutes while running. Production identifiers are configured for `suko-pro`; real customer activation still needs verification. Normal packaging refuses a paid release until production organization and licence-benefit IDs are set. `package.ps1 -Preview` can create a labelled review/test ZIP without enabling the rug or fabricating a licence.

Configured public identifiers:

- Organization: `a28b4803-e177-4bb7-93b6-a07c0dfab041`
- License Keys benefit: `efb934fc-d408-44b9-9e5d-61a0429367bd`
- Customer portal: https://polar.sh/suko-pro/portal
- Environment: production (`Sandbox = false`)

## Configure Polar

1. Create a **License Keys** benefit and attach it to the same one-time $1 product as the File Downloads benefit.
2. Set **activation limit to 1**, and enable customers to deactivate devices in Polar. For a purchase without a term limit, leave expiry and usage quotas unset.
3. Fill `OrganizationId`, `LicenseBenefitId` and `CustomerPortalUrl` in `LicenseConfig.cs`. These are public identifiers, not secret access tokens. Use the ID of the **License Keys benefit**, not the file benefit or product.
4. Test with the matching sandbox IDs and `Sandbox = true` using `dotnet run -c Release`. Sandbox keys do not work against production.
5. Set `Sandbox = false`, use production IDs, and test a genuine entitled key before uploading a production ZIP. Plain `package.ps1` permits production configuration only. Its automated suite mocks Polar; test the actual product/benefit in sandbox and the production integration with a provider-approved no-charge entitlement before selling.

Polar's public customer-portal endpoints are designed for desktop clients and require no secret token. The app submits the customer key, organization, activation ID, licence-benefit ID during validation, and a hash condition for the PC and Windows user. It sends neither raw MachineGuid nor raw Windows SID. [Official API documentation](https://polar.sh/docs/features/benefits/license-keys).

## Customer flow

`Purchase → Polar key + file → download → launch → paste key → activate this PC → rug starts`

Buyers find their key in Polar purchases. The activation window opens the configured portal. Windows DPAPI protects the saved key and activation ID in `%LOCALAPPDATA%\Kilim.Windows\activation.dat`, for the current Windows user with machine/user-bound entropy. Keys are not written to settings.json or error logs.

Copying the app folder does not copy its activation. Copying activation.dat to another PC or Windows account fails decryption/binding. Entering the key elsewhere is rejected by Polar while its single slot is allocated.

To move a key, select **Deactivate this PC** in the tray menu. Kilim closes and removes saved credentials after successful deactivation. Customers can also deactivate the old PC in Polar. **Forget saved key** clears local storage only; it does not free a server slot. Use it after releasing the old activation or recovering a damaged file.

## Validation and failures

Checks require granted status, the configured organization and licence benefit, the exact key, valid expiry, matching activation identity and one-device limit. The app passes the original device condition to validation. No local paid flag or credential cache bypasses online checking.

Internet access is required for activation, every launch and checks every 30 minutes. On invalidity, revocation, expiry, timeout or connection failure, the rug closes; reconnect and reopen to retry. There is no offline grace period. Revocation is detected at the next check rather than instantly.

Requests do not follow redirects and have a 12-second timeout. Provider error bodies are not shown or logged because they can echo keys. Retrying saved credentials validates rather than allocating another slot. A newly created activation that fails verification is released where possible; if a connection loss hides its outcome, manage any allocated slot in the portal.

Refunds stop future validation only if the licence benefit is revoked/disabled in Polar. Choose benefit revocation when refunding. Rotated old keys stop validating; manage the previous activation and enter the replacement key.

## Run the checks

```powershell
dotnet build -c Release
dotnet .\bin\Release\net8.0-windows\Kilim.Windows.dll --license-selftest .\diagnostics\licensing
dotnet .\bin\Release\net8.0-windows\Kilim.Windows.dll --selftest .\diagnostics\models
dotnet .\bin\Release\net8.0-windows\Kilim.Windows.dll --license-preview .\diagnostics\activation-window.png
```

The licence suite mocks Polar; it tests activation/deactivation, product/device checks, expiry, revocation, network failures, encrypted credentials, copying, corruption and missing configuration. It never sends a real key or purchases a product. Results go to license-report.json.

`--icons` and offscreen model diagnostics do not start a rug. `--desktop-test` validates a saved licence; without one it exits without desktop windows. It is not a licence bypass.

## Existing distribution and limitations

Previously shipped 0.1.0 copies do not acquire enforcement retroactively. The earlier Cloudflare deployment is a separate deployment and is unchanged. Retire/replace old free downloads when launching the configured paid build.

This limits ordinary key/binary sharing, not all tampering. Someone can patch a local binary; MIT recipients may modify/rebuild the source. Preserve MIT notices and freedoms and do not claim absolute copy prevention.

## Before the paid release

- Configure and test actual sandbox/production identifiers and both product benefits.
- Test second-PC denial, device deactivation, reinstall recovery, refunded/revoked keys and rotation against Polar.
- Build the 0.3.0 archive and update size, checksum, version and source links together.
- Upload the configured app to Polar's protected File Downloads benefit.
- Explain licence-key activation, online checks and local Windows credential storage to buyers before payment.
