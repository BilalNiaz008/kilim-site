using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Json;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace Kilim;

internal sealed class LicenseError : Exception
{
    public bool Retryable { get; }
    public LicenseError(string message, bool retryable = false) : base(message) { Retryable = retryable; }
}

internal sealed record LicenseState(string Key, string ActivationId, string Device, string OrganizationId, string BenefitId, bool Sandbox);

internal sealed class LicenseStore
{
    readonly string file;
    readonly string device;
    readonly byte[] entropy;
    public LicenseStore(string file, string device)
    {
        this.file = file; this.device = device;
        entropy = SHA256.HashData(Encoding.UTF8.GetBytes("Kilim.Windows.activation.v1:" + device));
    }
    public static string DeviceId()
    {
        using var registry = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64);
        using var key = registry.OpenSubKey("SOFTWARE\\Microsoft\\Cryptography");
        string? machine = key?.GetValue("MachineGuid") as string;
        using var identity = WindowsIdentity.GetCurrent();
        string? user = identity.User?.Value;
        if (string.IsNullOrWhiteSpace(machine) || string.IsNullOrWhiteSpace(user))
            throw new LicenseError("Windows could not identify this PC and user. Contact support before activating.");
        // Send only a hash, never the machine GUID or user SID, as the Polar activation condition.
        return Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(machine + ":" + user))).ToLowerInvariant();
    }
    public LicenseState? Load()
    {
        if (!File.Exists(file)) return null;
        try
        {
            if (new FileInfo(file).Length > 16384) throw new CryptographicException();
            byte[] clear = ProtectedData.Unprotect(File.ReadAllBytes(file), entropy, DataProtectionScope.CurrentUser);
            try
            {
                var state = JsonSerializer.Deserialize<LicenseState>(clear);
                if (state == null || state.Device != device || !Guid.TryParse(state.ActivationId, out var id) || id == Guid.Empty ||
                    string.IsNullOrWhiteSpace(state.Key) || state.Key.Length > 500)
                    throw new CryptographicException();
                return state;
            }
            finally { CryptographicOperations.ZeroMemory(clear); }
        }
        catch (Exception error) when (error is IOException or UnauthorizedAccessException or CryptographicException or JsonException)
        { throw new LicenseError("The saved activation cannot be read on this Windows account. Recover or deactivate the old activation in your Polar purchases, then enter your key again."); }
    }
    public void Save(LicenseState state)
    {
        if (state.Device != device) throw new LicenseError("This activation belongs to a different PC.");
        byte[] clear = JsonSerializer.SerializeToUtf8Bytes(state);
        try
        {
            byte[] encrypted = ProtectedData.Protect(clear, entropy, DataProtectionScope.CurrentUser);
            Directory.CreateDirectory(Path.GetDirectoryName(file)!);
            string temp = file + ".tmp"; File.WriteAllBytes(temp, encrypted); File.Move(temp, file, true);
        }
        finally { CryptographicOperations.ZeroMemory(clear); }
    }
    public void Delete() { if (File.Exists(file)) File.Delete(file); }
}

internal sealed class LicenseClient : IDisposable
{
    readonly Guid organization, benefit;
    readonly HttpClient http;
    public bool Sandbox { get; }
    public bool Configured => organization != Guid.Empty && benefit != Guid.Empty;
    public LicenseClient(string organizationId, string benefitId, bool sandbox, HttpMessageHandler? handler = null)
    {
        Guid.TryParse(organizationId, out organization); Guid.TryParse(benefitId, out benefit); Sandbox = sandbox;
        http = new HttpClient(handler ?? new HttpClientHandler { AllowAutoRedirect = false })
        {
            BaseAddress = new Uri(sandbox ? "https://sandbox-api.polar.sh/" : "https://api.polar.sh/"),
            Timeout = TimeSpan.FromSeconds(12), MaxResponseContentBufferSize = 256 * 1024
        };
        http.DefaultRequestHeaders.UserAgent.ParseAdd("Kilim.Windows/0.3.0");
    }
    void RequireConfiguration()
    {
        if (!Configured) throw new LicenseError("This build is awaiting its Polar licence configuration. Ask the publisher for a configured build.");
    }
    static void RequireKey(string key)
    {
        if (string.IsNullOrWhiteSpace(key) || key.Length > 500 || key.IndexOfAny(new[] { '\r', '\n', '\0' }) >= 0)
            throw new LicenseError("Paste the licence key from your Polar purchases.");
    }
    async Task<JsonDocument?> Post(string action, object body, CancellationToken cancellation = default)
    {
        RequireConfiguration();
        try
        {
            using var response = await http.PostAsJsonAsync("v1/customer-portal/license-keys/" + action, body, cancellation);
            if (response.StatusCode == HttpStatusCode.NoContent) return null;
            if (!response.IsSuccessStatusCode)
            {
                int status = (int)response.StatusCode;
                if (status == 429 || status >= 500) throw new LicenseError("Polar could not check the licence right now. Please try again shortly.", true);
                // Do not expose provider error bodies: they may include submitted keys or personal data.
                throw new LicenseError(action == "activate"
                    ? "This key cannot activate here. Check the key, its expiry and the one-device limit in your Polar purchases."
                    : "This licence or PC activation is no longer valid. Check your key and active devices in your Polar purchases.");
            }
            return JsonDocument.Parse(await response.Content.ReadAsStringAsync(cancellation));
        }
        catch (OperationCanceledException) when (!cancellation.IsCancellationRequested)
        { throw new LicenseError("The licence check timed out. Connect to the internet and retry.", true); }
        catch (HttpRequestException) { throw new LicenseError("Polar could not be reached. Connect to the internet and retry.", true); }
        catch (JsonException) { throw new LicenseError("Polar returned an unreadable licence response. Please retry.", true); }
    }
    static string String(JsonElement value, string name) => value.TryGetProperty(name, out var property) && property.ValueKind == JsonValueKind.String ? property.GetString()! : "";
    static Guid Id(JsonElement value, string name) => Guid.TryParse(String(value, name), out var id) ? id : Guid.Empty;
    internal void CheckLicense(JsonElement license, string key, DateTimeOffset now)
    {
        if (license.ValueKind != JsonValueKind.Object || Id(license, "id") == Guid.Empty || Id(license, "organization_id") != organization || Id(license, "benefit_id") != benefit ||
            String(license, "status") != "granted" || String(license, "key") != key)
            throw new LicenseError("This key is not a valid Kilim for Windows licence.");
        if (!license.TryGetProperty("limit_activations", out var limit) || limit.ValueKind != JsonValueKind.Number || !limit.TryGetInt32(out int count) || count != 1)
            throw new LicenseError("This build requires a Polar licence with its activation limit set to one.");
        if (!license.TryGetProperty("expires_at", out var expiry)) throw new LicenseError("The licence expiry response was incomplete.");
        if (expiry.ValueKind != JsonValueKind.Null && (expiry.ValueKind != JsonValueKind.String ||
            !DateTimeOffset.TryParse(expiry.GetString(), CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal, out var date) || date <= now))
            throw new LicenseError("This licence has expired or its expiry could not be verified.");
    }
    public async Task<LicenseState> Activate(string key, string device, CancellationToken cancellation = default)
    {
        RequireConfiguration(); key = key.Trim(); RequireKey(key);
        if (string.IsNullOrWhiteSpace(device) || device.Length > 100) throw new LicenseError("This PC could not be identified.");
        using var response = await Post("activate", new { key, organization_id = organization, label = "Windows PC " + device[..Math.Min(8, device.Length)], conditions = new { device } }, cancellation);
        if (response == null) throw new LicenseError("Polar returned an incomplete activation.");
        var root = response.RootElement;
        if (root.ValueKind != JsonValueKind.Object) throw new LicenseError("Polar returned an incomplete activation.");
        Guid activation = Id(root, "id");
        if (activation == Guid.Empty) throw new LicenseError("Polar returned an incomplete activation.");
        var state = new LicenseState(key, activation.ToString(), device, organization.ToString(), benefit.ToString(), Sandbox);
        try
        {
            if (!root.TryGetProperty("license_key", out var license)) throw new LicenseError("Polar returned an incomplete activation.");
            CheckLicense(license, key, DateTimeOffset.UtcNow);
            if (Id(root, "license_key_id") != Id(license, "id")) throw new LicenseError("The activation did not match this licence.");
            await Validate(state, cancellation);
            return state;
        }
        catch
        {
            // Release an allocation created for a wrong benefit or an unusable response where possible.
            try { await Deactivate(state, CancellationToken.None); } catch (LicenseError) { }
            throw;
        }
    }
    public async Task Validate(LicenseState state, CancellationToken cancellation = default)
    {
        RequireConfiguration(); RequireKey(state.Key);
        if (!Guid.TryParse(state.OrganizationId, out var org) || org != organization ||
            !Guid.TryParse(state.BenefitId, out var ben) || ben != benefit || state.Sandbox != Sandbox ||
            !Guid.TryParse(state.ActivationId, out var activation) || activation == Guid.Empty)
            throw new LicenseError("This saved activation belongs to a different build. Use the correct build or deactivate it in Polar.");
        using var response = await Post("validate", new { key = state.Key, organization_id = organization, benefit_id = benefit, activation_id = activation, conditions = new { device = state.Device } }, cancellation);
        if (response == null) throw new LicenseError("Polar did not return a licence validation.");
        var license = response.RootElement; CheckLicense(license, state.Key, DateTimeOffset.UtcNow);
        if (!license.TryGetProperty("activation", out var instance) || instance.ValueKind != JsonValueKind.Object ||
            Id(instance, "id") != activation || Id(instance, "license_key_id") != Id(license, "id"))
            throw new LicenseError("The licence is not activated for this PC.");
    }
    public async Task Deactivate(LicenseState state, CancellationToken cancellation = default)
    {
        RequireConfiguration(); RequireKey(state.Key);
        if (!Guid.TryParse(state.ActivationId, out var activation) || activation == Guid.Empty)
            throw new LicenseError("This activation ID is invalid.");
        using var response = await Post("deactivate", new { key = state.Key, organization_id = organization, activation_id = state.ActivationId }, cancellation);
        if (response != null) throw new LicenseError("Polar did not confirm that the activation was removed. Check your devices in Polar.");
    }
    public void Dispose() => http.Dispose();
}

internal sealed class Licensing : IDisposable
{
    public readonly LicenseClient Client = new(LicenseConfig.OrganizationId, LicenseConfig.LicenseBenefitId, LicenseConfig.Sandbox);
    readonly LicenseStore store;
    readonly string device;
    public LicenseState? State { get; private set; }
    public Licensing()
    {
        device = LicenseStore.DeviceId();
        store = new LicenseStore(Path.Combine(Settings.Folder, "activation.dat"), device);
    }
    public async Task<bool> Restore(CancellationToken cancellation = default)
    {
        var saved = store.Load();
        if (saved == null) return false;
        await Client.Validate(saved, cancellation); State = saved; return true;
    }
    public async Task Activate(string key, CancellationToken cancellation = default)
    {
        // Retry saved credentials first, so an outage never consumes another activation slot.
        var saved = store.Load();
        if (saved != null && saved.Key == key.Trim()) { await Client.Validate(saved, cancellation); State = saved; return; }
        if (saved != null) throw new LicenseError("Deactivate the saved key in your Polar purchases before using a different key. Use Forget saved key after deactivating it.");
        var activated = await Client.Activate(key, device, cancellation);
        try { store.Save(activated); State = activated; }
        catch (Exception error) when (error is IOException or UnauthorizedAccessException or CryptographicException)
        {
            try { await Client.Deactivate(activated, CancellationToken.None); } catch (LicenseError) { }
            throw new LicenseError("Windows could not save this activation. Check folder permissions and retry. If a slot remains allocated, deactivate it in your Polar purchases.");
        }
    }
    public Task Validate(CancellationToken cancellation = default) => State != null ? Client.Validate(State, cancellation) : throw new LicenseError("Activate your licence before using the app.");
    public async Task Deactivate(CancellationToken cancellation = default)
    {
        var saved = State ?? store.Load(); if (saved == null) return;
        await Client.Deactivate(saved, cancellation); store.Delete(); State = null;
    }
    public void Forget() { store.Delete(); State = null; }
    public void Dispose() => Client.Dispose();
}
