namespace Kilim;

// Public Polar identifiers, compiled into the app. Never put a secret access token here.
internal static class LicenseConfig
{
    public const string OrganizationId = "a28b4803-e177-4bb7-93b6-a07c0dfab041";
    public const string LicenseBenefitId = "efb934fc-d408-44b9-9e5d-61a0429367bd";
    public const bool Sandbox = false;
    public const string CustomerPortalUrl = "https://polar.sh/suko-pro/portal";
}
