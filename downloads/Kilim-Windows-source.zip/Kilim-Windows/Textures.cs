using System;
using System.Collections.Generic;
using System.IO;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Kilim;

internal static class Textures
{
    public static readonly string[] Themes = { "kashan", "isfahan", "tebriz", "turkmen", "kilim", "turk", "kurd", "egypt", "khayamiya", "berber", "kazak", "china", "ayasofya", "iznik", "selcuklu" };
    public static BitmapSource Load(string theme)
    {
        // ponytail: reuse upstream 640px previews; port the original pattern painter if larger texture detail is needed.
        if (theme == "custom" && File.Exists(Settings.CustomFile)) return Custom(Settings.CustomFile);
        if (Array.IndexOf(Themes, theme) < 0) throw new ArgumentException("Unknown rug theme.");
        var image = Decode(Path.Combine(AppContext.BaseDirectory, "assets", theme + ".jpg"), 0);
        int w = image.PixelWidth, h = image.PixelHeight;
        var pixels = new byte[w * h * 4]; image.CopyPixels(pixels, w * 4, 0);
        // Upstream preview JPEGs have a white background. Remove only edge-connected white,
        // preserving cream motifs enclosed by the rug border.
        var visited = new bool[w * h]; var queue = new Queue<int>();
        void Add(int x, int y)
        {
            if (x < 0 || x >= w || y < 0 || y >= h) return;
            int n = y * w + x, p = n * 4;
            if (visited[n] || pixels[p] < 240 || pixels[p + 1] < 240 || pixels[p + 2] < 240) return;
            visited[n] = true; queue.Enqueue(n);
        }
        for (int x = 0; x < w; x++) { Add(x, 0); Add(x, h - 1); }
        for (int y = 0; y < h; y++) { Add(0, y); Add(w - 1, y); }
        while (queue.Count > 0)
        {
            int n = queue.Dequeue(), p = n * 4; pixels[p] = pixels[p + 1] = pixels[p + 2] = pixels[p + 3] = 0;
            int x = n % w, y = n / w; Add(x - 1, y); Add(x + 1, y); Add(x, y - 1); Add(x, y + 1);
        }
        return Bitmap(w, h, pixels);
    }

    static BitmapSource Decode(string file, int maxWidth)
    {
        using var stream = File.OpenRead(file);
        if (stream.Length > 50 * 1024 * 1024) throw new InvalidDataException("Choose an image smaller than 50 MB.");
        var probe = BitmapDecoder.Create(stream, BitmapCreateOptions.DelayCreation, BitmapCacheOption.None);
        int width = probe.Frames[0].PixelWidth, height = probe.Frames[0].PixelHeight;
        if (width <= 0 || height <= 0 || width > 100000 || height > 100000) throw new InvalidDataException("Unsupported image dimensions.");
        stream.Position = 0;
        var image = new BitmapImage(); image.BeginInit(); image.CacheOption = BitmapCacheOption.OnLoad;
        if (maxWidth > 0) { if (width >= height) image.DecodePixelWidth = Math.Min(width, maxWidth); else image.DecodePixelHeight = Math.Min(height, maxWidth); }
        image.StreamSource = stream; image.EndInit(); image.Freeze();
        var converted = new FormatConvertedBitmap(image, PixelFormats.Bgra32, null, 0); converted.Freeze(); return converted;
    }
    static BitmapSource Bitmap(int w, int h, byte[] pixels)
    { var result = BitmapSource.Create(w, h, 96, 96, PixelFormats.Bgra32, null, pixels, w * 4); result.Freeze(); return result; }
    public static BitmapSource Shadow(BitmapSource image)
    {
        int w = image.PixelWidth, h = image.PixelHeight; var p = new byte[w * h * 4]; image.CopyPixels(p, w * 4, 0);
        for (int i = 0; i < p.Length; i += 4) { p[i] = p[i + 1] = p[i + 2] = 0; p[i + 3] = (byte)(p[i + 3] * .24); }
        return Bitmap(w, h, p);
    }
    public static BitmapSource Back(BitmapSource image)
    {
        int w = image.PixelWidth, h = image.PixelHeight; var p = new byte[w * h * 4]; image.CopyPixels(p, w * 4, 0);
        for (int i = 0; i < p.Length; i += 4)
        {
            float gray = p[i] * .11f + p[i + 1] * .59f + p[i + 2] * .30f;
            for (int c = 0; c < 3; c++) p[i + c] = (byte)Math.Clamp((p[i + c] * .62f + gray * .38f) * .8f + 5, 0, 255);
        }
        return Bitmap(w, h, p);
    }
    public static void Import(string file)
    {
        var image = Decode(file, 1400); Directory.CreateDirectory(Settings.Folder);
        var encoder = new PngBitmapEncoder(); encoder.Frames.Add(BitmapFrame.Create(image));
        string temp = Settings.CustomFile + ".tmp";
        using (var output = File.Create(temp)) encoder.Save(output);
        File.Move(temp, Settings.CustomFile, true);
    }
    public static BitmapSource Custom(string file)
    {
        var image = Decode(file, 180); var source = new byte[image.PixelWidth * image.PixelHeight * 4]; image.CopyPixels(source, image.PixelWidth * 4, 0);
        const int w = 768, h = 516; var pixels = new byte[w * h * 4]; var random = new Random(42);
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++)
        {
            int p = (y * w + x) * 4;
            if (x < 18 || x >= w - 18) { if (y % 7 < 2) { pixels[p] = 190; pixels[p + 1] = 219; pixels[p + 2] = 237; pixels[p + 3] = 255; } continue; }
            bool border = x < 90 || x >= w - 90 || y < 72 || y >= h - 72;
            if (border)
            {
                bool pattern = ((x / 9 + y / 9) & 1) == 0;
                pixels[p] = pattern ? (byte)34 : (byte)170; pixels[p + 1] = pattern ? (byte)34 : (byte)196; pixels[p + 2] = pattern ? (byte)94 : (byte)228;
            }
            else
            {
                // ponytail: coarse aspect-fill grid; use a higher-resolution textile renderer when exported prints are needed.
                double scale = Math.Max(588d / image.PixelWidth, 372d / image.PixelHeight);
                int sx = Math.Clamp((int)((((x - 90) / 4 * 4) - 294) / scale + image.PixelWidth / 2d), 0, image.PixelWidth - 1);
                int sy = Math.Clamp((int)((((y - 72) / 4 * 4) - 186) / scale + image.PixelHeight / 2d), 0, image.PixelHeight - 1);
                int q = (sy * image.PixelWidth + sx) * 4;
                for (int c = 0; c < 3; c++) pixels[p + c] = (byte)Math.Clamp(Math.Round(source[q + c] / 51d) * 51 + random.Next(-4, 5), 0, 255);
                if ((x - 90) % 4 == 3 || (y - 72) % 4 == 3) for (int c = 0; c < 3; c++) pixels[p + c] = (byte)(pixels[p + c] * .8);
            }
            pixels[p + 3] = 255;
        }
        return Bitmap(w, h, pixels);
    }
}
