# Kilim for Windows — licensed beta 0.3.0

A Windows adaptation of [Kilim](https://github.com/yusufyilmazfr/kilim), based on upstream commit `7fd785efd00900fa70af7288730c4a9029a18858`.

## Run

This source prepares the $1 Polar product with one-PC licence activation. The app requires a valid licence before the desktop rug starts. Internet access is required at activation, every launch and for checks every 30 minutes. The same licence slot is bound to one PC and Windows user.

Production Polar configuration is set for `suko-pro` in `LicenseConfig.cs`. Buyers manage their key and devices at [Polar purchases](https://polar.sh/suko-pro/portal). No merchant access token belongs in the executable. Attach the configured License Keys benefit and File Downloads benefit to the same $1 product, and verify real activation before selling. Read [LICENSING.md](LICENSING.md).

`package.ps1` refuses a normal customer release while identifiers are missing or sandbox mode is enabled. Run `package.ps1 -Preview` for a clearly labelled package to review and test; do not upload that preview to a paid File Downloads benefit. Mocked tests are not live Polar verification.

The [direct Cloudflare download](https://kilim-windows-download.suko-app.workers.dev/download/Kilim-Windows-0.1.0-beta-win-x64.zip) serves beta 0.1.0. There is no download website. Deployment instructions are in [cloudflare/README.md](cloudflare/README.md).

The configured customer package is `dist/Kilim-Windows-0.3.0-beta-win-x64.zip`. It targets **64-bit Intel/AMD Windows 10/11** and includes the .NET runtime. Extract the complete ZIP, keep `assets` beside `Kilim.Windows.exe`, open it and enter the key from Polar purchases. No .NET installation or administrator access is required.

The rug runs at desktop level and its controls are in the system tray near the clock (sometimes inside the hidden-icons arrow). Only one instance runs at a time. This beta is unsigned; Windows may show an unknown-publisher warning. It is an unofficial adaptation, independently packaged from upstream Kilim.

The older `release` folder and `dotnet run -c Release` developer command use your installed .NET 8 Desktop Runtime.

- Drag the rug to carry or fold it.
- Double-click the rug to roll/unroll it.
- Hold **Control** to fade it and click desktop icons. Release Control before dropping a file if you want to move it rather than copy it. Peek remains active until the mouse button is released.
- **Ctrl+Alt+K** hides/shows the rug, if the shortcut is available.
- Right-click the tray icon for patterns, a custom image, size, lighting, volume, peek key, flattening, icon rescan, launch at sign-in and Quit.

Fifteen upstream rug patterns plus a custom-photo rug are included. Settings, custom images and Windows-protected activation credentials stay in `%LOCALAPPDATA%\Kilim.Windows`. Licence checks contact Polar and submit a hashed device condition, never the raw machine GUID or Windows user SID. Launch at sign-in is off until selected. Desktop files are neither moved nor hidden through Explorer settings.

## Build and check

Install the .NET 8 SDK, then:

```powershell
dotnet build -c Release
dotnet .\bin\Release\net8.0-windows\Kilim.Windows.dll --selftest .\diagnostics
dotnet .\bin\Release\net8.0-windows\Kilim.Windows.dll --icons
dotnet .\bin\Release\net8.0-windows\Kilim.Windows.dll --license-selftest .\diagnostics\licensing
```

`--selftest` verifies cloth/contact/picking/roll/resize, all textures, custom weaving and synthesized audio, and generates PNG previews plus a JSON report. It does not change desktop icons or saved settings. `--icons` performs a read-only UI Automation query and returns screen-coordinate icon centres.

## Create a package for other users

From PowerShell in this project folder, run:

```powershell
.\package.ps1
```

With valid production IDs configured, this publishes a self-contained x64 executable, runs model/render and mocked licence checks, and writes a ZIP and SHA-256 under `dist`. The first build downloads Microsoft's runtime packs. The ZIP includes artwork, instructions and licence notices. Sending the executable alone omits the rug artwork.

For an unconfigured or sandbox test package instead, use `./package.ps1 -Preview`. Its filename and `PREVIEW-NOT-FOR-SALE.txt` marker identify it as unsuitable for customer delivery. The older free 0.1.0/0.2.0 ZIPs remain unchanged and cannot enforce paid licences retroactively.

To move the licence, deactivate this PC through the tray or Polar before activating another. To remove the app, turn off launch at sign-in if enabled, quit and delete its extracted folder. Saved preferences can be removed separately from `%LOCALAPPDATA%\Kilim.Windows`; deleting local files alone does not free the Polar licence slot.

## Windows implementation

- **Physics:** C# port of the upstream 44 × 30 Verlet cloth, 7,552 constraints, 22 solver passes, friction, spatial-hash self-collision, icon height field and spiral roll/unroll.
- **Desktop:** UI Automation reads Explorer's icon bounds in a helper process with a four-second timeout. Layered tool windows sit immediately above Explorer's icon host and pass the mouse through outside the rug or during peek. Explorer is not injected into or restarted.
- **Rendering:** WPF's native 3D renderer replaces Metal. One view per display renders a single shared cloth in physical screen coordinates, with shaded front/back surfaces, a soft projected shadow and clock-based lighting.
- **Rug artwork:** The 15 upstream MIT-licensed 640-pixel preview images are reused with edge-connected white removed for transparency. This beta does not port the original 2,000-line procedural pattern painter. Custom photos use a local coarse six-level textile texture.
- **Audio:** A small procedural rustle/thump synth feeds Windows `waveOut`; shared parameters use atomic reads/writes. Muting and volume are available.

The UI is English. The original 21-language menus, exact Metal shading, runtime pattern painting and drag-and-drop onto the tray icon are not reproduced; a file picker provides custom images. Windows shell variations, mixed-DPI monitor changes and Show Desktop behaviour need testing on other PCs. This is a local unsigned beta, not a signed installer or a claim of universal compatibility.

## Attribution

Original simulation and rug artwork: © 2026 Yusuf Yılmaz, MIT license. See `LICENSE` and `assets/UPSTREAM-LICENSE.txt`. Windows adaptation source is distributed under the same license.
