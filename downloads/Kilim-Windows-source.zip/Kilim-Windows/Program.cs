using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Microsoft.Win32;
using Forms = System.Windows.Forms;

namespace Kilim;

internal static class Program
{
    [STAThread]
    public static int Main(string[] args)
    {
        Desktop.SetProcessDpiAwarenessContext((nint)(-4));
        try
        {
            if (args.Contains("--icons"))
            {
                var icons = Task.Run(Desktop.ReadIcons).GetAwaiter().GetResult();
                Console.WriteLine(JsonSerializer.Serialize(icons)); return 0;
            }
            if (args.Contains("--selftest")) return Diagnostics.Run(args);
            if (args.Contains("--license-selftest")) return LicenseChecks.Run(args).GetAwaiter().GetResult();
            if (args.Length == 2 && args[0] == "--license-preview") { LicenseWindow.SavePreview(args[1]); return 0; }
            using var singleton = new Mutex(true, "Local\\Kilim.Windows.Desktop", out bool acquired);
            if (!acquired) return 0;
            var app = new Application { ShutdownMode = ShutdownMode.OnExplicitShutdown };
            string? smoke = args.Length > 1 && args[0] == "--desktop-test" ? Path.GetFullPath(args[1]) : null;
            using var licensing = new Licensing();
            if (smoke != null)
            {
                if (!Task.Run(() => licensing.Restore()).GetAwaiter().GetResult())
                    throw new LicenseError("Activate your licence before running a desktop test.");
            }
            else if (new LicenseWindow(licensing).ShowDialog() != true) return 0;
            using var controller = new Controller(app, licensing, smoke);
            app.Run(); return 0;
        }
        catch (Exception e)
        {
            if (args.Length > 0) { Console.Error.WriteLine(e); return 1; }
            MessageBox.Show(e.Message, "Kilim for Windows", MessageBoxButton.OK, MessageBoxImage.Error); return 1;
        }
    }
}

internal sealed class Overlay : Window
{
    public readonly Scene Scene;
    public nint Handle;
    readonly Controller controller;
    readonly System.Drawing.Rectangle bounds;
    public Overlay(Controller owner, Forms.Screen screen, Vector2 offset, BitmapSource texture)
    {
        controller = owner; bounds = screen.Bounds;
        Title = "Kilim desktop rug"; WindowStyle = WindowStyle.None; ResizeMode = ResizeMode.NoResize;
        AllowsTransparency = true; Background = Brushes.Transparent; ShowInTaskbar = false; ShowActivated = false;
        Width = screen.Bounds.Width; Height = screen.Bounds.Height; Left = screen.Bounds.X; Top = screen.Bounds.Y;
        Scene = new Scene(screen.Bounds.Width, screen.Bounds.Height, offset, texture);
        var host = new System.Windows.Controls.Grid { Background = Brushes.Transparent }; host.Children.Add(Scene); Content = host;
        SourceInitialized += (_, _) =>
        {
            Handle = new WindowInteropHelper(this).Handle;
            HwndSource.FromHwnd(Handle).AddHook(Hook);
            Desktop.ClickThrough(Handle, true);
            Desktop.SetWindowPos(Handle, 0, bounds.X, bounds.Y, bounds.Width, bounds.Height, 0x4 | 0x10);
            Desktop.PlaceAboveIcons(Handle);
        };
        MouseLeftButtonDown += (_, e) =>
        {
            if (e.ClickCount >= 2) { controller.EndGrab(); controller.ToggleRoll(); }
            else if (controller.BeginGrab()) { Mouse.Capture(this); Cursor = Cursors.Hand; }
            e.Handled = true;
        };
        MouseMove += (_, _) => { if (controller.Cloth.Grabbed) controller.MoveGrab(); };
        MouseLeftButtonUp += (_, _) => { if (controller.Cloth.Grabbed) { controller.EndGrab(); Mouse.Capture(null); Cursor = Cursors.Arrow; } };
        LostMouseCapture += (_, _) => controller.EndGrab();
    }
    nint Hook(nint hwnd, int msg, nint wp, nint lp, ref bool handled)
    {
        if (msg == 0x21) { handled = true; return 3; } // WM_MOUSEACTIVATE / MA_NOACTIVATE
        if (msg == 0x312 && wp == 1) { controller.ToggleHidden(); handled = true; }
        return 0;
    }
}

internal sealed class Controller : IDisposable
{
    readonly Application app;
    readonly Licensing licensing;
    readonly DispatcherTimer licenceTimer = new() { Interval = TimeSpan.FromMinutes(30) };
    bool licenceBusy;
    readonly Settings settings = Settings.Load();
    public readonly Cloth Cloth = new();
    readonly List<Overlay> overlays = new();
    readonly Audio audio = new();
    readonly Forms.NotifyIcon tray = new();
    readonly DispatcherTimer poll = new() { Interval = TimeSpan.FromMilliseconds(50) };
    readonly Stopwatch clock = Stopwatch.StartNew();
    readonly string? smokeFile;
    int renderedFrames;
    double worstFrame, totalFrame;
    BitmapSource texture;
    Vector2 origin;
    string layout = "";
    bool hidden, peek, previousMouse, iconBusy, disposed, asleep, menuDirty;
    int dragBump = -1, themeRequest;
    Vector2 dragOffset, dragStart;
    bool dragMoved;
    double lastTime, accumulator, nextScan, nextStack, nextLight, lastRelease = -10;
    float alpha = 1;
    string iconStatus = "Reading desktop icons...";
    nint hotkeyWindow;
    Process? iconProcess;

    public Controller(Application application, Licensing licence, string? smoke = null)
    {
        if (licence.State == null) throw new LicenseError("Activate your licence before starting the rug.");
        app = application; licensing = licence; smokeFile = smoke; texture = Textures.Load(settings.Theme);
        RebuildDisplays(true); ResetRug();
        tray.Icon = System.Drawing.SystemIcons.Application; tray.Text = "Kilim for Windows"; tray.Visible = true;
        tray.DoubleClick += (_, _) => ToggleHidden(); BuildMenu();
        poll.Tick += (_, _) => Poll(); poll.Start();
        CompositionTarget.Rendering += Render;
        ScanIcons();
        licenceTimer.Tick += async (_, _) =>
        {
            if (licenceBusy || disposed) return;
            licenceBusy = true;
            try { await licensing.Validate(); }
            catch (LicenseError error)
            {
                if (disposed) return;
                Dispose();
                MessageBox.Show(error.Message + "\n\nKilim has closed. Reopen it after resolving the licence or connection issue.", "Kilim licence check");
                app.Shutdown();
            }
            finally { licenceBusy = false; }
        };
        licenceTimer.Start();
        if (smokeFile != null)
        {
            var finish = new DispatcherTimer { Interval = TimeSpan.FromSeconds(10) };
            finish.Tick += (_, _) =>
            {
                finish.Stop();
                var (_, iconList) = Desktop.FindIcons();
                var windows = overlays.Select(o =>
                {
                    Desktop.GetWindowRect(o.Handle, out var rect);
                    bool above = false; for (nint w = Desktop.GetWindow(o.Handle, 2); w != 0; w = Desktop.GetWindow(w, 2)) if (w == Desktop.GetAncestor(iconList, 2)) { above = true; break; }
                    bool below = false; for (nint w = Desktop.GetWindow(Desktop.GetForegroundWindow(), 2); w != 0; w = Desktop.GetWindow(w, 2)) if (w == o.Handle) { below = true; break; }
                    return new { visible = Desktop.IsWindowVisible(o.Handle), aboveDesktopIcons = above, belowForegroundWindow = below, left = rect.Left, top = rect.Top, width = rect.Right - rect.Left, height = rect.Bottom - rect.Top, noActivate = (Desktop.Style(o.Handle) & 0x08000000) != 0 };
                }).ToArray();
                Directory.CreateDirectory(Path.GetDirectoryName(smokeFile)!);
                File.WriteAllText(smokeFile, JsonSerializer.Serialize(new { windows, iconCount = Cloth.Bumps.Count, iconStatus, renderedFrames, averageFrameCpuMs = totalFrame / Math.Max(1, renderedFrames), worstFrameCpuMs = worstFrame, asleep, audioError = audio.Error }, new JsonSerializerOptions { WriteIndented = true }));
                app.Shutdown();
            };
            finish.Start();
        }
    }
    string ScreenLayout() => string.Join(";", Forms.Screen.AllScreens.Select(s => s.DeviceName + s.Bounds.ToString()));
    void RebuildDisplays(bool initial)
    {
        var screens = Forms.Screen.AllScreens; if (screens.Length == 0) return;
        int minX = screens.Min(s => s.Bounds.Left), minY = screens.Min(s => s.Bounds.Top);
        var nextOrigin = new Vector2(minX, minY);
        if (!initial) { EndGrab(); Cloth.Translate(origin - nextOrigin); }
        origin = nextOrigin; Cloth.ViewWidth = screens.Max(s => s.Bounds.Right) - minX; Cloth.ViewHeight = screens.Max(s => s.Bounds.Bottom) - minY;
        if (hotkeyWindow != 0) Desktop.UnregisterHotKey(hotkeyWindow, 1);
        foreach (var overlay in overlays) overlay.Close(); overlays.Clear();
        foreach (var screen in screens)
        {
            var overlay = new Overlay(this, screen, new Vector2(screen.Bounds.X, screen.Bounds.Y) - origin, texture);
            overlays.Add(overlay); overlay.Show(); if (hidden || !Desktop.PlaceAboveIcons(overlay.Handle)) overlay.Hide();
        }
        hotkeyWindow = overlays[0].Handle;
        Desktop.RegisterHotKey(hotkeyWindow, 1, 0x0002 | 0x0001 | 0x4000, 0x4b); // Ctrl+Alt+K; no key repeat
        layout = ScreenLayout(); Cloth.Project(); Wake();
    }
    float RugWidth()
    {
        var primary = Forms.Screen.PrimaryScreen ?? Forms.Screen.AllScreens[0]; float w = primary.Bounds.Width;
        float factor = settings.Size switch { "S" => .7f, "L" => 1.45f, "XL" => 2, _ => 1 };
        return MathF.Min(Math.Clamp(w * .36f, 420, 760) * factor, w * .92f);
    }
    void ResetRug()
    {
        EndGrab(); var b = (Forms.Screen.PrimaryScreen ?? Forms.Screen.AllScreens[0]).Bounds;
        Cloth.Reset(new Vector2(b.X + b.Width * .4f, b.Y + b.Height * .52f) - origin, RugWidth()); Wake();
    }
    Vector2 Pointer => Desktop.Cursor() - origin;
    void Wake()
    {
        Cloth.Settled = 0;
        if (asleep) { asleep = false; lastTime = clock.Elapsed.TotalSeconds; accumulator = 0; CompositionTarget.Rendering += Render; }
    }
    public bool BeginGrab() { if (peek || hidden) return false; bool ok = Cloth.BeginGrab(Pointer); if (ok) Wake(); return ok; }
    public void MoveGrab() { Cloth.MoveGrab(Pointer); Wake(); }
    public void EndGrab() { if (!Cloth.Grabbed) return; Cloth.EndGrab(); lastRelease = clock.Elapsed.TotalSeconds; Wake(); }
    public void ToggleRoll() { if (hidden) ToggleHidden(); Cloth.ToggleRoll(Pointer.X > Cloth.Center().X); Wake(); }
    public void ToggleHidden()
    {
        hidden = !hidden; EndGrab(); Mouse.Capture(null);
        foreach (var overlay in overlays) { if (hidden) overlay.Hide(); else { overlay.Show(); Desktop.PlaceAboveIcons(overlay.Handle); } }
        if (hidden) audio.Quiet(); else Wake(); BuildMenu();
    }
    void Poll()
    {
        double now = clock.Elapsed.TotalSeconds;
        if (menuDirty && tray.ContextMenuStrip?.Visible != true) BuildMenu();
        bool mouse = Desktop.Down(1), held = Desktop.Down(settings.Peek switch { "Shift" => 0x10, "Alt" => 0x12, _ => 0x11 });
        bool nextPeek = held || (peek && mouse);
        if (peek != nextPeek) { peek = nextPeek; Wake(); }
        var p = Pointer;
        if (Cloth.Grabbed && !mouse) { EndGrab(); Mouse.Capture(null); }
        if (!Cloth.Grabbed && !hidden)
        {
            if (mouse && !previousMouse)
            {
                dragBump = -1; float best = 42 * 42;
                if (Desktop.CursorOverIcons()) for (int i = 0; i < Cloth.Bumps.Count; i++) { float d = Vector2.DistanceSquared(Cloth.Bumps[i], p); if (d < best) { best = d; dragBump = i; } }
                if (dragBump >= 0) { dragOffset = Cloth.Bumps[dragBump] - p; dragStart = p; dragMoved = false; }
            }
            if (mouse && dragBump >= 0 && dragBump < Cloth.Bumps.Count && (dragMoved || Vector2.DistanceSquared(p, dragStart) > 36))
            { dragMoved = true; Cloth.Bumps[dragBump] = p + dragOffset; Wake(); }
            if (!mouse && previousMouse) { dragBump = -1; dragMoved = false; nextScan = Math.Min(nextScan, now + .7); }
        }
        bool over = !hidden && !peek && !mouse && Cloth.Hit(p) >= 0;
        foreach (var overlay in overlays)
        {
            bool inScreen = p.X >= overlay.Scene.Offset.X && p.X < overlay.Scene.Offset.X + overlay.Scene.ViewWidth && p.Y >= overlay.Scene.Offset.Y && p.Y < overlay.Scene.Offset.Y + overlay.Scene.ViewHeight;
            Desktop.ClickThrough(overlay.Handle, !Cloth.Grabbed && !(over && inScreen));
        }
        previousMouse = mouse;
        if (now >= nextStack)
        {
            nextStack = now + 1;
            if (ScreenLayout() != layout) { RebuildDisplays(false); nextScan = now; }
            foreach (var overlay in overlays) if (!hidden)
            {
                if (!Desktop.PlaceAboveIcons(overlay.Handle)) overlay.Hide();
                else if (!overlay.IsVisible) { overlay.Show(); Desktop.PlaceAboveIcons(overlay.Handle); Wake(); }
            }
        }
        if (now >= nextScan && !hidden && !Cloth.Grabbed && !dragMoved) { nextScan = now + 4; ScanIcons(); }
        if (now >= nextLight) { nextLight = now + 60; if (settings.Light == "auto" && !hidden) Wake(); }
    }
    void Render(object? sender, EventArgs e)
    {
        if (disposed || hidden) { Sleep(); return; }
        long start = Stopwatch.GetTimestamp();
        double now = clock.Elapsed.TotalSeconds;
        accumulator += Math.Min(now - lastTime, .05); lastTime = now;
        int steps = 0;
        while (accumulator >= 1 / 60d && steps < 2) { Cloth.Step(); accumulator -= 1 / 60d; steps++; }
        if (steps == 2) accumulator = 0;
        if (steps > 0) audio.Feed(Cloth, settings.Sound, settings.Volume, Cloth.Grabbed || now - lastRelease < .9, now);
        float target = peek ? .26f : 1;
        if (MathF.Abs(alpha - target) > .012f) { alpha += (target - alpha) * .28f; Cloth.Settled = 0; } else alpha = target;
        foreach (var overlay in overlays) overlay.Scene.Update(Cloth, settings.Light, alpha);
        double cpu = Stopwatch.GetElapsedTime(start).TotalMilliseconds; renderedFrames++; totalFrame += cpu; worstFrame = Math.Max(worstFrame, cpu);
        if (Cloth.Settled > 45 && !Cloth.Grabbed && alpha == target) Sleep();
    }
    void Sleep() { if (asleep) return; asleep = true; CompositionTarget.Rendering -= Render; audio.Quiet(); }
    async void ScanIcons()
    {
        if (iconBusy || disposed) return; iconBusy = true;
        try
        {
            // Isolate UI Automation: a blocked Explorer provider cannot freeze the rug or an endless worker.
            using var process = new Process { StartInfo = new ProcessStartInfo(Environment.ProcessPath!, "--icons")
            { UseShellExecute = false, CreateNoWindow = true, WindowStyle = ProcessWindowStyle.Hidden, RedirectStandardOutput = true, RedirectStandardError = true } };
            process.Start(); iconProcess = process; var output = process.StandardOutput.ReadToEndAsync(); var errors = process.StandardError.ReadToEndAsync();
            using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(4));
            try { await process.WaitForExitAsync(timeout.Token); }
            catch (OperationCanceledException) { if (!process.HasExited) process.Kill(); throw new TimeoutException("Explorer did not answer within four seconds."); }
            string text = await output; string error = await errors;
            if (process.ExitCode != 0) throw new InvalidOperationException(error.Length > 0 ? error : "Desktop icons unavailable.");
            var points = JsonSerializer.Deserialize<float[][]>(text) ?? Array.Empty<float[]>();
            var bumps = points.Where(p => p.Length == 2 && float.IsFinite(p[0]) && float.IsFinite(p[1])).Select(p => new Vector2(p[0], p[1]) - origin)
                .Where(p => p.X >= -60 && p.X <= Cloth.ViewWidth + 60 && p.Y >= -60 && p.Y <= Cloth.ViewHeight + 60).ToList();
            if (disposed) return;
            if (!Cloth.Bumps.SequenceEqual(bumps) && !Cloth.Grabbed && !dragMoved) { Cloth.Bumps = bumps; Wake(); }
            iconStatus = bumps.Count + " desktop icon bumps";
        }
        catch (Exception error) { iconStatus = "Icon scan unavailable; rug still works"; Log(error); }
        finally { iconProcess = null; iconBusy = false; if (!disposed) BuildMenu(); }
    }
    void Save() { if (smokeFile != null) return; try { settings.Save(); } catch (Exception e) { Log(e); tray.ShowBalloonTip(3000, "Kilim", "Settings could not be saved: " + e.Message, Forms.ToolTipIcon.Warning); } }
    void BuildMenu()
    {
        if (tray.ContextMenuStrip?.Visible == true) { menuDirty = true; return; }
        menuDirty = false;
        var menu = new Forms.ContextMenuStrip();
        void Item(string title, Action action, bool check = false) { var item = new Forms.ToolStripMenuItem(title) { Checked = check }; item.Click += (_, _) => action(); menu.Items.Add(item); }
        void Choices(string title, string[] values, string current, Action<string> action)
        {
            var sub = new Forms.ToolStripMenuItem(title);
            foreach (string value in values) { var item = new Forms.ToolStripMenuItem(value) { Checked = value == current }; item.Click += (_, _) => action(value); sub.DropDownItems.Add(item); }
            menu.Items.Add(sub);
        }
        menu.Items.Add(new Forms.ToolStripMenuItem(iconStatus) { Enabled = false });
        Item(hidden ? "Show rug (Ctrl+Alt+K)" : "Hide rug (Ctrl+Alt+K)", ToggleHidden);
        Item("Toss / flatten rug", ResetRug); Item(Cloth.Rolling ? "Unroll rug" : "Roll rug", ToggleRoll); Item("Rescan desktop", ScanIcons);
        Choices("Rug pattern", Textures.Themes.Concat(File.Exists(Settings.CustomFile) ? new[] { "custom" } : Array.Empty<string>()).ToArray(), settings.Theme, ApplyTheme);
        Item("Use my picture...", () =>
        {
            var picker = new OpenFileDialog { Filter = "Images|*.png;*.jpg;*.jpeg;*.bmp;*.gif;*.tif;*.tiff", Title = "Weave a picture into a rug" };
            if (picker.ShowDialog() != true) return;
            try { Textures.Import(picker.FileName); ApplyTheme("custom"); } catch (Exception e) { Log(e); MessageBox.Show(e.Message, "Could not load picture"); }
        });
        Choices("Light", new[] { "auto", "day", "evening", "night" }, settings.Light, v => { settings.Light = v; Save(); Wake(); BuildMenu(); });
        Choices("Size", new[] { "S", "M", "L", "XL" }, settings.Size, v => { settings.Size = v; if (Cloth.Rolling || Cloth.Grabbed) ResetRug(); else Cloth.Scale(RugWidth() / Cloth.Width); Save(); Wake(); BuildMenu(); });
        Choices("Peek key (hold to click icons)", new[] { "Control", "Shift", "Alt" }, settings.Peek, v => { settings.Peek = v; Save(); BuildMenu(); });
        Item("Sounds", () => { settings.Sound = !settings.Sound; Volatile.Write(ref audio.Synth.Volume, settings.Sound ? settings.Volume : 0); Save(); BuildMenu(); }, settings.Sound);
        Choices("Volume", new[] { "25%", "50%", "75%", "100%" }, (int)(settings.Volume * 100) + "%", v => { settings.Volume = int.Parse(v.TrimEnd('%')) / 100f; Save(); Wake(); BuildMenu(); });
        Item("Launch at sign-in", ToggleLogin, LoginEnabled());
        menu.Items.Add(new Forms.ToolStripSeparator());
        Item("Polar purchases / manage devices", LicenseWindow.OpenPortal);
        Item("Deactivate this PC...", async () =>
        {
            if (licenceBusy || MessageBox.Show("Deactivate this PC and quit Kilim? Your key can then be activated on another PC.",
                "Move licence", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
            licenceBusy = true;
            try { await licensing.Deactivate(); app.Shutdown(); }
            catch (LicenseError error) { if (!disposed) MessageBox.Show(error.Message, "Could not deactivate licence"); }
            catch (Exception error) when (error is IOException or UnauthorizedAccessException)
            {
                if (!disposed)
                {
                    Dispose();
                    MessageBox.Show("The PC was deactivated, but its saved file could not be removed. Manage activations in Polar.", "Licence storage");
                    app.Shutdown();
                }
            }
            finally { licenceBusy = false; }
        });
        Item("Open local settings folder", () => { Directory.CreateDirectory(Settings.Folder); Process.Start(new ProcessStartInfo(Settings.Folder) { UseShellExecute = true }); });
        Item("Quit Kilim", () => app.Shutdown());
        var old = tray.ContextMenuStrip; tray.ContextMenuStrip = menu; old?.Dispose();
    }
    async void ApplyTheme(string theme)
    {
        int request = ++themeRequest;
        try
        {
            var image = await Task.Run(() => Textures.Load(theme));
            if (disposed || request != themeRequest) return;
            texture = image; settings.Theme = theme; foreach (var overlay in overlays) overlay.Scene.SetTexture(image); Save(); Wake(); BuildMenu();
        }
        catch (Exception e) { Log(e); if (!disposed) MessageBox.Show(e.Message, "Could not load rug"); }
    }
    static bool LoginEnabled()
    {
        using var key = Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Run");
        return key?.GetValue("Kilim.Windows") is string;
    }
    void ToggleLogin()
    {
        try
        {
            using var key = Registry.CurrentUser.CreateSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Run");
            if (key.GetValue("Kilim.Windows") != null) key.DeleteValue("Kilim.Windows"); else key.SetValue("Kilim.Windows", "\"" + Environment.ProcessPath + "\"");
            BuildMenu();
        }
        catch (Exception e) { Log(e); MessageBox.Show(e.Message, "Could not change launch at sign-in"); }
    }
    void Log(Exception e)
    {
        if (smokeFile != null) return;
        try { Directory.CreateDirectory(Settings.Folder); File.AppendAllText(Path.Combine(Settings.Folder, "kilim.log"), DateTime.Now + " " + e.Message + Environment.NewLine); } catch (IOException) { }
    }
    public void Dispose()
    {
        if (disposed) return;
        disposed = true; poll.Stop(); licenceTimer.Stop(); CompositionTarget.Rendering -= Render;
        if (iconProcess != null) { try { if (!iconProcess.HasExited) iconProcess.Kill(); } catch (InvalidOperationException) { } }
        if (hotkeyWindow != 0) Desktop.UnregisterHotKey(hotkeyWindow, 1);
        Mouse.Capture(null); foreach (var overlay in overlays) overlay.Close();
        tray.Visible = false; tray.Dispose(); audio.Dispose();
    }
}
