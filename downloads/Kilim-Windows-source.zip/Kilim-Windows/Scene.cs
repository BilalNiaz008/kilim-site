using System;
using System.Numerics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;

namespace Kilim;

internal sealed class Scene : Grid
{
    readonly MeshGeometry3D mesh = new(), shadow = new();
    readonly GeometryModel3D rug, shade;
    readonly AmbientLight ambient = new(Color.FromRgb(105, 105, 105));
    readonly DirectionalLight sun = new(Colors.White, new Vector3D(.45, -.55, -.75));
    readonly Viewport3D viewport = new(), shadowView = new();
    public float ViewWidth { get; private set; }
    public float ViewHeight { get; private set; }
    public Vector2 Offset;

    public Scene(float width, float height, Vector2 offset, BitmapSource texture)
    {
        ViewWidth = width; ViewHeight = height; Offset = offset;
        Background = Brushes.Transparent; IsHitTestVisible = false;
        var indices = new Int32Collection(); var uv = new PointCollection();
        for (int j = 0; j < Cloth.NY; j++) for (int i = 0; i < Cloth.NX; i++) uv.Add(new Point(i / (Cloth.NX - 1d), j / (Cloth.NY - 1d)));
        for (int j = 0; j < Cloth.NY - 1; j++) for (int i = 0; i < Cloth.NX - 1; i++)
        { int a = j * Cloth.NX + i, b = a + 1, c = a + Cloth.NX, d = c + 1; foreach (int k in new[] { a, c, b, b, c, d }) indices.Add(k); }
        indices.Freeze(); uv.Freeze(); mesh.TriangleIndices = shadow.TriangleIndices = indices; mesh.TextureCoordinates = shadow.TextureCoordinates = uv;
        rug = new GeometryModel3D { Geometry = mesh }; shade = new GeometryModel3D { Geometry = shadow };
        var group = new Model3DGroup(); group.Children.Add(ambient); group.Children.Add(sun); group.Children.Add(rug);
        viewport.Children.Add(new ModelVisual3D { Content = group }); shadowView.Children.Add(new ModelVisual3D { Content = shade });
        var camera = new OrthographicCamera(new Point3D(0, 0, 1200), new Vector3D(0, 0, -1), new Vector3D(0, 1, 0), width) { NearPlaneDistance = .1, FarPlaneDistance = 2500 };
        camera.Freeze(); viewport.Camera = shadowView.Camera = camera;
        // WPF provides the native 3D rasterizer and shadow blur; no custom graphics dependency.
        shadowView.Effect = new BlurEffect { Radius = 7, RenderingBias = RenderingBias.Performance };
        Children.Add(shadowView); Children.Add(viewport); SetTexture(texture);
    }

    public void SetTexture(BitmapSource image)
    {
        var brush = new ImageBrush(image); brush.Freeze();
        var front = new MaterialGroup(); front.Children.Add(new DiffuseMaterial(brush)); front.Children.Add(new SpecularMaterial(new SolidColorBrush(Color.FromRgb(35, 32, 29)), 28)); front.Freeze();
        rug.Material = front;
        var back = new DiffuseMaterial(new ImageBrush(Textures.Back(image))); back.Freeze(); rug.BackMaterial = back;
        var material = new EmissiveMaterial(new ImageBrush(Textures.Shadow(image))); material.Freeze(); shade.Material = shade.BackMaterial = material;
    }
    public void Update(Cloth cloth, string mode, float alpha, DateTime? clock = null)
    {
        double hour = mode switch { "day" => 12.5, "evening" => 18, "night" => 23, _ => (clock ?? DateTime.Now).TimeOfDay.TotalHours };
        double elevation = hour > 6 && hour < 19 ? Math.Sin(Math.PI * (hour - 6) / 13) : -.3;
        double t = Math.Clamp((elevation + .02) / .24, 0, 1), day = t * t * (3 - 2 * t);
        double az = Math.Clamp((hour - 12.5) / 6.5, -1, 1);
        var light = Vector3.Normalize(Vector3.Lerp(new(-.35f, -.5f, .8f), new((float)(az * .95), -.35f, (float)(Math.Max(.2, elevation) * 1.2)), (float)day));
        double warmth = (1 - Math.Clamp(elevation / .55, 0, 1)) * day;
        var tint = Vector3.Lerp(new(.50f, .58f, .84f), Vector3.Lerp(new(1, .99f, .96f), new(1, .8f, .58f), (float)warmth), (float)day);
        Color ColorAt(float strength) => Color.FromRgb((byte)Math.Clamp(tint.X * 255 * strength, 0, 255), (byte)Math.Clamp(tint.Y * 255 * strength, 0, 255), (byte)Math.Clamp(tint.Z * 255 * strength, 0, 255));
        ambient.Color = ColorAt(.46f); sun.Color = ColorAt((float)(.35 + .65 * day)); sun.Direction = new Vector3D(-light.X, light.Y, -light.Z);
        float sx = Math.Clamp(-light.X / light.Z * .55f, -1.7f, 1.7f), sy = Math.Clamp(-light.Y / light.Z * .55f, -1.7f, 1.7f);
        var positions = new Point3DCollection(Cloth.Count); var normals = new Vector3DCollection(Cloth.Count); var shadowPositions = new Point3DCollection(Cloth.Count);
        for (int j = 0; j < Cloth.NY; j++) for (int i = 0; i < Cloth.NX; i++)
        {
            int k = j * Cloth.NX + i; var p = cloth.P[k]; var screen = cloth.Screen[k] - Offset;
            positions.Add(new(screen.X - ViewWidth / 2, ViewHeight / 2 - screen.Y, p.Z));
            var x = cloth.P[j * Cloth.NX + Math.Min(i + 1, Cloth.NX - 1)] - cloth.P[j * Cloth.NX + Math.Max(i - 1, 0)];
            var y = cloth.P[Math.Min(j + 1, Cloth.NY - 1) * Cloth.NX + i] - cloth.P[Math.Max(j - 1, 0) * Cloth.NX + i];
            var a = new Vector3(x.X, -x.Y, x.Z * 2.6f); var b = new Vector3(y.X, -y.Y, y.Z * 2.6f); var n = Vector3.Cross(b, a);
            n = n.LengthSquared() > 1e-12f ? Vector3.Normalize(n) : Vector3.UnitZ; normals.Add(new(n.X, n.Y, n.Z));
            float shx = p.X - Offset.X + sx * (p.Z + 2.6f) + .4f, shy = p.Y - Offset.Y + sy * (p.Z + 2.6f) + 2;
            shadowPositions.Add(new(shx - ViewWidth / 2, ViewHeight / 2 - shy, 0));
        }
        mesh.Positions = positions; mesh.Normals = normals; shadow.Positions = shadowPositions; Opacity = alpha;
    }
    public static void SavePreview(Scene scene, string file, int width, int height)
    {
        scene.Width = width; scene.Height = height;
        scene.Measure(new Size(width, height)); scene.Arrange(new Rect(0, 0, width, height)); scene.UpdateLayout();
        var bitmap = new RenderTargetBitmap(width, height, 96, 96, PixelFormats.Pbgra32); bitmap.Render(scene);
        var png = new PngBitmapEncoder(); png.Frames.Add(BitmapFrame.Create(bitmap));
        using var stream = System.IO.File.Create(file); png.Save(stream);
    }
}
