using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Numerics;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Automation;

namespace Kilim;

internal static class Desktop
{
    internal delegate bool EnumProc(nint window, nint parameter);
    [StructLayout(LayoutKind.Sequential)] internal struct Point { public int X, Y; }
    [StructLayout(LayoutKind.Sequential)] internal struct Bounds { public int Left, Top, Right, Bottom; }
    [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc callback, nint parameter);
    [DllImport("user32.dll")] static extern bool EnumChildWindows(nint parent, EnumProc callback, nint parameter);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern nint FindWindowEx(nint parent, nint after, string cls, string? name);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetClassName(nint window, StringBuilder text, int length);
    [DllImport("user32.dll")] internal static extern nint GetAncestor(nint window, uint flags);
    [DllImport("user32.dll")] internal static extern nint GetWindow(nint window, uint command);
    [DllImport("user32.dll")] internal static extern nint GetForegroundWindow();
    [DllImport("user32.dll")] internal static extern bool IsWindow(nint window);
    [DllImport("user32.dll")] internal static extern bool IsWindowVisible(nint window);
    [DllImport("user32.dll")] internal static extern bool GetWindowRect(nint window, out Bounds bounds);
    [DllImport("user32.dll", SetLastError = true)] internal static extern bool SetWindowPos(nint window, nint after, int x, int y, int width, int height, uint flags);
    [DllImport("user32.dll", EntryPoint = "GetWindowLongPtrW")] static extern nint GetStyle64(nint window, int index);
    [DllImport("user32.dll", EntryPoint = "SetWindowLongPtrW")] static extern nint SetStyle64(nint window, int index, nint value);
    [DllImport("user32.dll", EntryPoint = "GetWindowLongW")] static extern int GetStyle32(nint window, int index);
    [DllImport("user32.dll", EntryPoint = "SetWindowLongW")] static extern int SetStyle32(nint window, int index, int value);
    [DllImport("user32.dll")] internal static extern short GetAsyncKeyState(int key);
    [DllImport("user32.dll")] static extern bool GetCursorPos(out Point point);
    [DllImport("user32.dll")] static extern nint WindowFromPoint(Point point);
    [DllImport("user32.dll")] internal static extern bool RegisterHotKey(nint window, int id, uint modifiers, uint key);
    [DllImport("user32.dll")] internal static extern bool UnregisterHotKey(nint window, int id);
    [DllImport("user32.dll")] internal static extern bool SetProcessDpiAwarenessContext(nint context);

    public static (nint root, nint list) FindIcons()
    {
        nint root = 0, list = 0;
        EnumWindows((window, _) =>
        {
            var def = FindWindowEx(window, 0, "SHELLDLL_DefView", null);
            if (def == 0) return true;
            EnumChildWindows(def, (child, _) =>
            {
                var name = new StringBuilder(128); GetClassName(child, name, name.Capacity);
                if (name.ToString() == "SysListView32") { list = child; return false; }
                return true;
            }, 0);
            if (list != 0) { root = GetAncestor(def, 2); return false; }
            return true;
        }, 0);
        return (root, list);
    }

    public static float[][] ReadIcons()
    {
        var (_, list) = FindIcons();
        if (list == 0) throw new InvalidOperationException("Explorer's desktop icon view is unavailable.");
        var element = AutomationElement.FromHandle(list);
        var request = new CacheRequest { TreeScope = TreeScope.Element };
        request.Add(AutomationElement.BoundingRectangleProperty);
        using (request.Activate())
        {
            var items = element.FindAll(TreeScope.Children, new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.ListItem));
            var result = new List<float[]>();
            foreach (AutomationElement item in items)
            {
                var bounds = item.Cached.BoundingRectangle;
                if (!bounds.IsEmpty && bounds.Width > 0 && bounds.Height > 0 && double.IsFinite(bounds.X) && double.IsFinite(bounds.Y))
                    result.Add(new[] { (float)(bounds.X + bounds.Width / 2), (float)(bounds.Y + Math.Min(bounds.Height / 2, bounds.Width / 2)) });
            }
            return result.ToArray();
        }
    }

    public static Vector2 Cursor() { return GetCursorPos(out var p) ? new(p.X, p.Y) : Vector2.Zero; }
    public static bool CursorOverIcons()
    {
        if (!GetCursorPos(out var p)) return false;
        var (root, list) = FindIcons();
        return list != 0 && GetAncestor(WindowFromPoint(p), 2) == root;
    }
    public static bool Down(int key) => (GetAsyncKeyState(key) & 0x8000) != 0;
    public static long Style(nint window) => IntPtr.Size == 8 ? GetStyle64(window, -20).ToInt64() : GetStyle32(window, -20);
    public static void ClickThrough(nint window, bool enabled)
    {
        long style = Style(window), updated = enabled ? style | 0x20 : style & ~0x20;
        updated |= 0x08000000 | 0x80; // no activation; tool window
        if (updated == style) return;
        if (IntPtr.Size == 8) SetStyle64(window, -20, (nint)updated); else SetStyle32(window, -20, (int)updated);
    }
    public static bool PlaceAboveIcons(nint window)
    {
        var (root, _) = FindIcons(); if (root == 0 || !IsWindow(root)) return false;
        nint previous = GetWindow(root, 3); // GW_HWNDPREV: insert behind the window above Explorer
        if (previous == window) return true;
        return SetWindowPos(window, previous, 0, 0, 0, 0, 0x1 | 0x2 | 0x10); // preserve size/position; no activation
    }
}
