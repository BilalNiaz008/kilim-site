using System;
using System.IO;
using System.Text.Json;

namespace Kilim;

internal sealed class Settings
{
    public string Theme { get; set; } = "kashan";
    public string Light { get; set; } = "auto";
    public string Size { get; set; } = "M";
    public string Peek { get; set; } = "Control";
    public bool Sound { get; set; } = true;
    public float Volume { get; set; } = .5f;
    public static string Folder => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Kilim.Windows");
    public static string CustomFile => Path.Combine(Folder, "custom.png");
    public static Settings Load()
    {
        try
        {
            var s = JsonSerializer.Deserialize<Settings>(File.ReadAllText(Path.Combine(Folder, "settings.json"))) ?? new Settings();
            if (Array.IndexOf(Textures.Themes, s.Theme) < 0 && s.Theme != "custom") s.Theme = "kashan";
            if (s.Theme == "custom" && !File.Exists(CustomFile)) s.Theme = "kashan";
            if (s.Light is not ("auto" or "day" or "evening" or "night")) s.Light = "auto";
            if (s.Size is not ("S" or "M" or "L" or "XL")) s.Size = "M";
            if (s.Peek is not ("Control" or "Shift" or "Alt")) s.Peek = "Control";
            s.Volume = float.IsFinite(s.Volume) ? Math.Clamp(s.Volume, 0, 1) : .5f;
            return s;
        }
        catch (Exception e) when (e is IOException or JsonException or UnauthorizedAccessException) { return new(); }
    }
    public void Save()
    {
        Directory.CreateDirectory(Folder);
        string file = Path.Combine(Folder, "settings.json"), temp = file + ".tmp";
        File.WriteAllText(temp, JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true }));
        File.Move(temp, file, true);
    }
}
