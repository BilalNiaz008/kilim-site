// Adapted from Kilim's MIT-licensed Cloth.swift and Roll.swift, Yusuf Yilmaz, 2026.
using System;
using System.Collections.Generic;
using System.Numerics;

namespace Kilim;

internal sealed class Cloth
{
    public const int NX = 44, NY = 30, Count = NX * NY;
    public const float Perspective = .0009f;
    public readonly Vector3[] P = new Vector3[Count], Old = new Vector3[Count];
    public readonly Vector2[] Screen = new Vector2[Count];
    readonly float[] floor = new float[Count];
    readonly bool[] pinned = new bool[Count];
    readonly int[] heads = new int[4096], next = new int[Count];
    readonly List<(int a, int b, float rest, float stiffness, int color)> constraints = new();
    readonly List<(int node, Vector2 offset, float lift)> pins = new();
    Vector2 cursor, rollCenter, rollX, rollY;
    Vector3[] rollStart = Array.Empty<Vector3>();
    float rollDirection, rollBlend;
    public List<Vector2> Bumps = new();
    public float ViewWidth = 1440, ViewHeight = 900, Width = 600, Height = 400;
    public float MaxSpeed, Slide, Impact, RollProgress, RollGoal;
    public int Settled;
    public bool Rolling { get; private set; }
    public bool Grabbed => pins.Count > 0;
    public int ConstraintCount => constraints.Count;

    public void Reset(Vector2 center, float width, float drop = 130, float angle = -.12f)
    {
        Width = width; Height = width * 1032 / 1536;
        float ca = MathF.Cos(angle), sa = MathF.Sin(angle);
        for (int j = 0; j < NY; j++) for (int i = 0; i < NX; i++)
        {
            float x = (i / (NX - 1f) - .5f) * Width, y = (j / (NY - 1f) - .5f) * Height;
            int k = j * NX + i;
            P[k] = Old[k] = new(center.X + x * ca - y * sa, center.Y + x * sa + y * ca, drop);
            pinned[k] = false; floor[k] = 0;
        }
        pins.Clear(); Rolling = false; RollProgress = RollGoal = 0; Settled = 0;
        BuildConstraints(); Project();
    }

    void BuildConstraints()
    {
        constraints.Clear();
        float dx = Width / (NX - 1), dy = Height / (NY - 1);
        void Add(int i, int j, int x, int y, float stiffness, int color)
        {
            if (i < 0 || i >= NX || j < 0 || j >= NY || x < 0 || x >= NX || y < 0 || y >= NY) return;
            float a = (x - i) * dx, b = (y - j) * dy;
            constraints.Add((j * NX + i, y * NX + x, MathF.Sqrt(a * a + b * b), stiffness, color));
        }
        for (int j = 0; j < NY; j++) for (int i = 0; i < NX; i++)
        {
            Add(i, j, i + 1, j, 1, i & 1); Add(i, j, i, j + 1, 1, 2 + (j & 1));
            Add(i, j, i + 1, j + 1, .55f, 4 + (i & 1) + 2 * (j & 1));
            Add(i + 1, j, i, j + 1, .55f, 8 + (i & 1) + 2 * (j & 1));
            Add(i, j, i + 2, j, .14f, 12 + (i & 3)); Add(i, j, i, j + 2, .14f, 16 + (j & 3));
        }
        constraints.Sort((a, b) => a.color.CompareTo(b.color));
    }

    public float HeightAt(float x, float y)
    {
        float h = 0;
        foreach (var b in Bumps)
        {
            float d2 = Vector2.DistanceSquared(new(x, y), b);
            if (d2 >= 48 * 48) continue;
            float u = MathF.Max(0, (MathF.Sqrt(d2) - 14) / 34);
            h += 20 * (1 - u * u * (3 - 2 * u));
        }
        return MathF.Min(h, 110);
    }

    public void Step()
    {
        if (Rolling) { StepRoll(); Project(); return; }
        MaxSpeed = Slide = Impact = 0;
        foreach (var pin in pins)
        {
            var p = P[pin.node];
            var move = (cursor + pin.offset - new Vector2(p.X, p.Y)) * .7f;
            if (move.LengthSquared() > 22 * 22) move = Vector2.Normalize(move) * 22;
            p.X += move.X; p.Y += move.Y; p.Z += (pin.lift - p.Z) * .2f;
            P[pin.node] = Old[pin.node] = p;
        }
        for (int i = 0; i < Count; i++)
        {
            if (pinned[i]) continue;
            var v = (P[i] - Old[i]) * new Vector3(.965f, .965f, .90f);
            float speed = MathF.Sqrt(v.X * v.X + v.Y * v.Y);
            if (P[i].Z - floor[i] < .8f)
            {
                if (speed > .25f) Slide += speed;
                float f = speed <= .85f ? 0 : (speed - .85f) / speed * .93f;
                v.X *= f; v.Y *= f;
            }
            speed = MathF.Sqrt(v.X * v.X + v.Y * v.Y);
            if (speed > 14) { v.X *= 14 / speed; v.Y *= 14 / speed; speed = 14; }
            MaxSpeed = MathF.Max(MaxSpeed, MathF.Max(speed, MathF.Abs(v.Z)));
            Old[i] = P[i]; P[i] += v - new Vector3(0, 0, .30f);
        }
        ComputeFloor(); ClampFloor(); Collide();
        for (int it = 0; it < 22; it++)
        {
            for (int k = 0; k < constraints.Count; k++)
            {
                var c = constraints[(it & 1) == 0 ? k : constraints.Count - 1 - k];
                var d = P[c.b] - P[c.a];
                float length = MathF.Sqrt(d.LengthSquared() + 1e-12f);
                float wa = pinned[c.a] ? 0 : 1, wb = pinned[c.b] ? 0 : 1;
                if (wa + wb == 0) continue;
                var correction = d * (c.stiffness * (1 - c.rest / length) / (wa + wb));
                P[c.a] += correction * wa; P[c.b] -= correction * wb;
            }
            if (it % 6 == 5) ClampFloor();
        }
        Collide(); ComputeFloor(); ClampFloor();
        for (int i = 0; i < Count; i++)
        {
            P[i].X = Math.Clamp(P[i].X, -200, ViewWidth + 200);
            P[i].Y = Math.Clamp(P[i].Y, -200, ViewHeight + 200);
        }
        Slide /= Count;
        Settled = MaxSpeed < .15f && !Grabbed ? Settled + 1 : 0;
        Project();
    }

    void ComputeFloor() { for (int i = 0; i < Count; i++) floor[i] = HeightAt(P[i].X, P[i].Y); }
    void ClampFloor()
    {
        for (int i = 0; i < Count; i++) if (P[i].Z < floor[i])
        {
            float v = Old[i].Z - P[i].Z; P[i].Z = floor[i];
            if (v > .6f) { Impact += v - .6f; Old[i].Z = floor[i]; }
            else if (Old[i].Z < floor[i]) Old[i].Z = floor[i];
        }
    }
    static int Hash(int x, int y, int z) => unchecked((x * 73856093 ^ y * 19349663 ^ z * 83492791) & 4095);
    void Collide()
    {
        Array.Fill(heads, -1);
        for (int i = 0; i < Count; i++)
        {
            var p = P[i]; int h = Hash((int)MathF.Floor(p.X / 10), (int)MathF.Floor(p.Y / 10), (int)MathF.Floor(p.Z / 10));
            next[i] = heads[h]; heads[h] = i;
        }
        for (int i = 0; i < Count; i++)
        {
            var p = P[i]; int cx = (int)MathF.Floor(p.X / 10), cy = (int)MathF.Floor(p.Y / 10), cz = (int)MathF.Floor(p.Z / 10);
            for (int z = -1; z <= 1; z++) for (int y = -1; y <= 1; y++) for (int x = -1; x <= 1; x++)
                for (int j = heads[Hash(cx + x, cy + y, cz + z)]; j >= 0; j = next[j])
                {
                    if (j <= i || (Math.Abs(i % NX - j % NX) <= 2 && Math.Abs(i / NX - j / NX) <= 2)) continue;
                    var d = P[i] - P[j]; float d2 = d.LengthSquared(); if (d2 >= 100) continue;
                    float wa = pinned[i] ? 0 : 1, wb = pinned[j] ? 0 : 1;
                    if (wa + wb == 0) continue;
                    float length = MathF.Sqrt(d2);
                    var normal = length < 1e-4f ? Vector3.UnitZ : d / length;
                    var correction = normal * ((10 - length) * .7f / (wa + wb));
                    P[i] += correction * wa; P[j] -= correction * wb;
                }
        }
    }

    public void Project()
    {
        var center = new Vector2(ViewWidth, ViewHeight) / 2;
        for (int i = 0; i < Count; i++) { var p = P[i]; var xy = new Vector2(p.X, p.Y); Screen[i] = xy + (xy - center) * p.Z * Perspective; }
    }
    Vector2 Unproject(Vector2 p, float z) => (p + new Vector2(ViewWidth, ViewHeight) / 2 * Perspective * z) / (1 + Perspective * z);
    public int Hit(Vector2 p)
    {
        int best = -1; float bestZ = float.MinValue;
        void Triangle(int a, int b, int c)
        {
            var u = Screen[a]; var v = Screen[b]; var w = Screen[c];
            float Sign(Vector2 q, Vector2 r) => (p.X - r.X) * (q.Y - r.Y) - (q.X - r.X) * (p.Y - r.Y);
            float d1 = Sign(u, v), d2 = Sign(v, w), d3 = Sign(w, u);
            if ((d1 < 0 || d2 < 0 || d3 < 0) && (d1 > 0 || d2 > 0 || d3 > 0)) return;
            float z = (P[a].Z + P[b].Z + P[c].Z) / 3;
            if (z <= bestZ) return;
            bestZ = z; best = a;
            if (Vector2.DistanceSquared(p, Screen[b]) < Vector2.DistanceSquared(p, Screen[best])) best = b;
            if (Vector2.DistanceSquared(p, Screen[c]) < Vector2.DistanceSquared(p, Screen[best])) best = c;
        }
        for (int j = 0; j < NY - 1; j++) for (int i = 0; i < NX - 1; i++)
        {
            int a = j * NX + i, b = a + 1, c = a + NX, d = c + 1;
            float minx = MathF.Min(MathF.Min(Screen[a].X, Screen[b].X), MathF.Min(Screen[c].X, Screen[d].X));
            float maxx = MathF.Max(MathF.Max(Screen[a].X, Screen[b].X), MathF.Max(Screen[c].X, Screen[d].X));
            float miny = MathF.Min(MathF.Min(Screen[a].Y, Screen[b].Y), MathF.Min(Screen[c].Y, Screen[d].Y));
            float maxy = MathF.Max(MathF.Max(Screen[a].Y, Screen[b].Y), MathF.Max(Screen[c].Y, Screen[d].Y));
            if (p.X < minx || p.X > maxx || p.Y < miny || p.Y > maxy) continue;
            Triangle(a, b, c); Triangle(b, d, c);
        }
        return best;
    }
    public bool BeginGrab(Vector2 p)
    {
        if (Rolling) return false;
        int hit = Hit(p); if (hit < 0) return false;
        EndGrab(); cursor = Unproject(p, 28); var center = P[hit]; float lift = MathF.Max(28, center.Z + 6);
        for (int i = 0; i < Count; i++)
        {
            var xy = new Vector2(P[i].X, P[i].Y); float d = Vector2.Distance(xy, new(center.X, center.Y));
            if (d < 26 && MathF.Abs(P[i].Z - center.Z) < 25)
            { pins.Add((i, xy - cursor, lift * (1 - .6f * d / 26))); pinned[i] = true; }
        }
        Settled = 0; return Grabbed;
    }
    public void MoveGrab(Vector2 p) { cursor = Unproject(Vector2.Clamp(p, Vector2.Zero, new(ViewWidth, ViewHeight)), 28); Settled = 0; }
    public void EndGrab()
    {
        for (int i = 0; i < Count; i++) { Old[i].X = P[i].X - (P[i].X - Old[i].X) * .1f; Old[i].Y = P[i].Y - (P[i].Y - Old[i].Y) * .1f; }
        foreach (var pin in pins) pinned[pin.node] = false;
        pins.Clear(); Settled = 0;
    }
    public void Scale(float factor)
    {
        if (Rolling || Grabbed || !float.IsFinite(factor) || factor <= 0) return;
        Vector2 center = Center();
        for (int i = 0; i < Count; i++)
        {
            P[i].X = center.X + (P[i].X - center.X) * factor; P[i].Y = center.Y + (P[i].Y - center.Y) * factor;
            Old[i].X = center.X + (Old[i].X - center.X) * factor; Old[i].Y = center.Y + (Old[i].Y - center.Y) * factor;
        }
        Width *= factor; Height *= factor; BuildConstraints(); Settled = 0; Project();
    }
    public Vector2 Center() { var c = Vector2.Zero; foreach (var p in P) c += new Vector2(p.X, p.Y); return c / Count; }
    public void Translate(Vector2 d)
    {
        for (int i = 0; i < Count; i++) { P[i] += new Vector3(d, 0); Old[i] += new Vector3(d, 0); }
        rollCenter += d; for (int i = 0; i < rollStart.Length; i++) rollStart[i] += new Vector3(d, 0);
        for (int i = 0; i < Bumps.Count; i++) Bumps[i] += d;
        Settled = 0; Project();
    }
    public void ToggleRoll(bool right)
    {
        if (Rolling) { RollGoal = RollGoal > .5f ? 0 : 1; rollBlend = 1; Settled = 0; return; }
        EndGrab(); rollCenter = Center(); var left = Vector2.Zero; var edge = Vector2.Zero;
        for (int j = 0; j < NY; j++) { left += new Vector2(P[j * NX].X, P[j * NX].Y); edge += new Vector2(P[j * NX + NX - 1].X, P[j * NX + NX - 1].Y); }
        rollX = (edge - left) / NY; rollX = rollX.Length() > 20 ? Vector2.Normalize(rollX) : Vector2.UnitX;
        if (rollX.X < 0) rollX = -rollX;
        rollY = new(-rollX.Y, rollX.X); rollDirection = right ? 1 : -1;
        rollStart = (Vector3[])P.Clone(); rollBlend = 0; RollProgress = 0; RollGoal = 1; Rolling = true; Settled = 0;
    }
    static float Smooth(float x) => x * x * (3 - 2 * x);
    static float Theta(float s) => (-5 + MathF.Sqrt(25 + 9 * s / MathF.PI)) / (9 / (2 * MathF.PI));
    void StepRoll()
    {
        bool moving = RollProgress != RollGoal || rollBlend < 1;
        RollProgress = RollProgress < RollGoal ? MathF.Min(RollGoal, RollProgress + 1 / 60f / 1.6f) : MathF.Max(RollGoal, RollProgress - 1 / 60f / 1.3f);
        rollBlend = MathF.Min(1, rollBlend + 1 / 60f / .45f); float sf = Width * Smooth(RollProgress), blend = Smooth(rollBlend);
        for (int j = 0; j < NY; j++) for (int i = 0; i < NX; i++)
        {
            float u = (i / (NX - 1f) - .5f) * Width, v = (j / (NY - 1f) - .5f) * Height;
            float a = rollDirection * u, s = a + Width / 2;
            var axis = rollX * rollDirection; var basis = rollCenter + rollY * v; Vector3 target;
            if (s <= sf)
            {
                float th = Theta(s), thf = Theta(sf), radius = 5 + 9 * th / (2 * MathF.PI), outer = 5 + 9 * thf / (2 * MathF.PI);
                float angle = -MathF.PI / 2 - (thf - th); var xy = basis + axis * (-Width / 2 + sf + radius * MathF.Cos(angle));
                target = new(xy, outer + radius * MathF.Sin(angle));
            }
            else { var xy = basis + axis * a; target = new(xy, HeightAt(xy.X, xy.Y)); }
            int k = j * NX + i; P[k] = Old[k] = blend < 1 ? Vector3.Lerp(rollStart[k], target, blend) : target;
            floor[k] = 0;
        }
        MaxSpeed = Impact = 0; Slide = moving ? 1.6f : 0; Settled = moving ? 0 : Settled + 1;
        if (RollProgress == 0 && RollGoal == 0 && rollBlend >= 1)
        {
            Rolling = false; for (int i = 0; i < Count; i++) { P[i].Z = MathF.Max(P[i].Z, 0) + .2f; Old[i].Z = P[i].Z; }
            Settled = 0;
        }
    }
}
