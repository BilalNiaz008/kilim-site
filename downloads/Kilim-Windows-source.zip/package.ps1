$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot

$project = [xml](Get-Content -LiteralPath 'Kilim.Windows.csproj' -Raw)
$version = [string]$project.Project.PropertyGroup.Version
$packageName = "Kilim-Windows-$version-win-x64"
$packageRoot = Join-Path $PSScriptRoot "dist\$packageName"

dotnet publish 'Kilim.Windows.csproj' -c Release -r win-x64 --self-contained true `
    -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true `
    -p:EnableCompressionInSingleFile=true -p:DebugType=None -p:DebugSymbols=false `
    -o $packageRoot
if ($LASTEXITCODE -ne 0) { throw 'Publishing failed.' }
if (@(Get-ChildItem -LiteralPath (Join-Path $packageRoot 'assets') -Filter '*.jpg').Count -ne 15) {
    throw 'Published artwork is incomplete.'
}

$assets = Get-Content -LiteralPath 'obj\project.assets.json' -Raw | ConvertFrom-Json
$noticeRoot = Join-Path $packageRoot 'licenses'
New-Item -ItemType Directory -Path $noticeRoot -Force | Out-Null
foreach ($runtime in @('Microsoft.NETCore.App.Runtime.win-x64', 'Microsoft.WindowsDesktop.App.Runtime.win-x64')) {
    $dependency = $assets.project.frameworks.PSObject.Properties | ForEach-Object { $_.Value.downloadDependencies } |
        Where-Object { $_.name -eq $runtime } | Select-Object -First 1
    if (!$dependency) { throw "Runtime package metadata missing: $runtime" }
    $runtimeVersion = [regex]::Match($dependency.version, '\d+\.\d+\.\d+').Value
    $runtimePath = $runtime.ToLowerInvariant() + '\' + $runtimeVersion
    $runtimeRoot = $assets.packageFolders.PSObject.Properties.Name | ForEach-Object { Join-Path $_ $runtimePath } |
        Where-Object { Test-Path -LiteralPath $_ -PathType Container } | Select-Object -First 1
    if (!$runtimeRoot) { throw "Runtime package files missing: $runtime" }
    foreach ($notice in @('LICENSE', 'LICENSE.TXT', 'THIRD-PARTY-NOTICES.TXT')) {
        $file = Join-Path $runtimeRoot $notice
        if (Test-Path -LiteralPath $file -PathType Leaf) {
            Copy-Item -LiteralPath $file -Destination (Join-Path $noticeRoot ($runtime + '-' + $notice))
        }
    }
}

$checkRoot = Join-Path $PSScriptRoot 'dist\verification'
New-Item -ItemType Directory -Path $checkRoot -Force | Out-Null
$checkArgs = '--selftest "' + $checkRoot + '"'
$process = Start-Process -FilePath (Join-Path $packageRoot 'Kilim.Windows.exe') `
    -ArgumentList $checkArgs -WindowStyle Hidden -Wait -PassThru `
    -RedirectStandardOutput (Join-Path $checkRoot 'stdout.txt') `
    -RedirectStandardError (Join-Path $checkRoot 'stderr.txt')
if ($process.ExitCode -ne 0) { throw ('Package self-test failed. See ' + $checkRoot) }
$report = Get-Content -LiteralPath (Join-Path $checkRoot 'report.json') -Raw | ConvertFrom-Json
if (!$report.passed) { throw 'Package model/render checks did not pass.' }

$archive = Join-Path $PSScriptRoot "dist\$packageName.zip"
Compress-Archive -LiteralPath $packageRoot -DestinationPath $archive -Force
$hash = (Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant()
Set-Content -LiteralPath ($archive + '.sha256') -Value "$hash  $packageName.zip" -Encoding ascii
Write-Output "Share this ZIP: $archive"
Write-Output ('Checks: ' + ($report.checks -join ', '))
