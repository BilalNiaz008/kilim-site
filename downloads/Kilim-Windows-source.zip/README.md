# Kilim for Windows — free beta 0.2.0

A Windows adaptation of [Kilim](https://github.com/yusufyilmazfr/kilim), based on upstream commit `7fd785efd00900fa70af7288730c4a9029a18858`.

## Run

This build is free and runs without payment, an account, an activation key or online licence checks. The self-contained package is `dist/Kilim-Windows-0.2.0-beta-win-x64.zip`.

The separate [Cloudflare download site](https://kilim-windows-download.suko-app.workers.dev) still serves the previous beta until redeployed; this task does not change that remote deployment. Its source and deployment instructions remain in [cloudflare/README.md](cloudflare/README.md).

For other users, share `Kilim-Windows-0.2.0-beta-win-x64.zip`. It targets **64-bit Intel/AMD Windows 10/11** and includes the .NET runtime. Extract the entire ZIP to a folder, keep the `assets` folder beside `Kilim.Windows.exe`, and double-click the executable. No .NET installation or administrator access is required.

The rug runs at desktop level and its controls are in the system tray near the clock (sometimes inside the hidden-icons arrow). Only one instance runs at a time. This beta is unsigned; Windows may show an unknown-publisher warning. It is an unofficial adaptation, independently packaged from upstream Kilim.

The older `release` folder and `dotnet run -c Release` developer command use your installed .NET 8 Desktop Runtime.

- Drag the rug to carry or fold it.
- Double-click the rug to roll/unroll it.
- Hold **Control** to fade it and click desktop icons. Release Control before dropping a file if you want to move it rather than copy it. Peek remains active until the mouse button is released.
- **Ctrl+Alt+K** hides/shows the rug, if the shortcut is available.
- Right-click the tray icon for patterns, a custom image, size, lighting, volume, peek key, flattening, icon rescan, launch at sign-in and Quit.

Fifteen upstream rug patterns plus a custom-photo rug are included. Settings and custom images stay in `%LOCALAPPDATA%\Kilim.Windows`. Launch at sign-in is off until selected; the app otherwise makes no installation or shell settings changes. Desktop files are neither moved nor hidden through Explorer settings.

## Build and check

Install the .NET 8 SDK, then:

```powershell
dotnet build -c Release
dotnet .\bin\Release\net8.0-windows\Kilim.Windows.dll --selftest .\diagnostics
dotnet .\bin\Release\net8.0-windows\Kilim.Windows.dll --icons
```

`--selftest` verifies cloth/contact/picking/roll/resize, all textures, custom weaving and synthesized audio, and generates PNG previews plus a JSON report. It does not change desktop icons or saved settings. `--icons` performs a read-only UI Automation query and returns screen-coordinate icon centres.

## Create a package for other users

From PowerShell in this project folder, run:

```powershell
.\package.ps1
```

This publishes a self-contained x64 executable, runs its model/render tests, and writes a versioned ZIP and SHA-256 checksum under `dist`. The initial build needs internet access to download Microsoft's runtime packs. Rug assets, usage instructions, upstream attribution and the bundled runtimes' license notices are included. The ZIP is the complete application; sending the executable by itself omits the rug artwork.

To remove the portable app, quit it from the tray and delete its extracted folder. If launch at sign-in was enabled, turn that setting off before deleting the folder. Saved preferences and custom images can be removed separately from `%LOCALAPPDATA%\Kilim.Windows`.

## Windows implementation

- **Physics:** C# port of the upstream 44 × 30 Verlet cloth, 7,552 constraints, 22 solver passes, friction, spatial-hash self-collision, icon height field and spiral roll/unroll.
- **Desktop:** UI Automation reads Explorer's icon bounds in a helper process with a four-second timeout. Layered tool windows sit immediately above Explorer's icon host and pass the mouse through outside the rug or during peek. Explorer is not injected into or restarted.
- **Rendering:** WPF's native 3D renderer replaces Metal. One view per display renders a single shared cloth in physical screen coordinates, with shaded front/back surfaces, a soft projected shadow and clock-based lighting.
- **Rug artwork:** The 15 upstream MIT-licensed 640-pixel preview images are reused with edge-connected white removed for transparency. This beta does not port the original 2,000-line procedural pattern painter. Custom photos use a local coarse six-level textile texture.
- **Audio:** A small procedural rustle/thump synth feeds Windows `waveOut`; shared parameters use atomic reads/writes. Muting and volume are available.

The UI is English. The original 21-language menus, exact Metal shading, runtime pattern painting and drag-and-drop onto the tray icon are not reproduced; a file picker provides custom images. Windows shell variations, mixed-DPI monitor changes and Show Desktop behaviour need testing on other PCs. This is a local unsigned beta, not a signed installer or a claim of universal compatibility.

## Attribution

Original simulation and rug artwork: © 2026 Yusuf Yılmaz, MIT license. See `LICENSE` and `assets/UPSTREAM-LICENSE.txt`. Windows adaptation source is distributed under the same license.
